# Databricks notebook source
# MAGIC %md
# MAGIC Logging for stages

# COMMAND ----------

import time
import pandas as pd
import os
from datetime import datetime

# Initialize an empty list to store log entries
log_entries = []
log_file_path_staged = os.path.join(workspace_path, datetime.now().strftime("%d%m%Y") + "_staged_logging_status.csv")

# Function to load log entries from the file
def load_log_entries(file_path):
    global log_entries
    if os.path.exists(file_path):
        if os.path.isdir(file_path):
            os.rmdir(file_path)  # Remove the directory if it exists
        else:
            log_entries = pd.read_csv(file_path).to_dict('records')

# Function to log a stage
def log_stage(stage, start_time, end_time, status, log_message):
    global log_entries
    log_entries.append({
        "Stage": stage,
        "Start Time": start_time,
        "End Time": end_time,
        "Status": status,
        "Log": log_message
    })
    # Write log entries to file after each log entry is added
    write_log_to_file(log_file_path_staged)

# Function to write log entries to a file
def write_log_to_file(file_path):
    global log_entries
    df_log = pd.DataFrame(log_entries)
    df_log.to_csv(file_path, index=False)

# Load log entries from the file when the environment is restarted
load_log_entries(log_file_path_staged)

# COMMAND ----------

# MAGIC %md
# MAGIC For Snowflake Fields

# COMMAND ----------

from pyspark.sql.functions import col, lit, when, coalesce, concat, length
from pyspark.sql.types import StructType, StructField, StringType
import time

def get_cd_value_column(flattened_df):
    return flattened_df.withColumn(
        'cd_value',
        coalesce(
            when((col('CD48').isNull()) | 
                 (col('CD48') == '') |
                 (col('CD48') == '^^^^^^^^^') | 
                 (col('CD48') == '000000000') |
                 (col('CD48') == '^^^^^^^^^^^') | 
                 (col('CD48') == '00000000000') |
                 (length(col('CD48')).isin([9, 11]) == False),
                 None
            ).otherwise(col('CD48')),
            when((col('CD93').isNull()) | 
                 (col('CD93') == '') |
                 (col('CD93') == '^^^^^^^^^') | 
                 (col('CD93') == '000000000') |
                 (col('CD93') == '^^^^^^^^^^^') | 
                 (col('CD93') == '00000000000') |
                 (length(col('CD93')).isin([9, 11]) == False),
                 None
            ).otherwise(col('CD93')),
            when((col('CD6').isNull()) | 
                 (col('CD6') == '') |
                 (col('CD6') == '^^^^^^^^^') | 
                 (col('CD6') == '000000000') |
                 (col('CD6') == '^^^^^^^^^^^') | 
                 (col('CD6') == '00000000000') |
                 (length(col('CD6')).isin([9, 11]) == False),
                 None
            ).otherwise(col('CD6')),
            lit("Not Available")
        )
    )

def process_member_details_with_snowflake(flattened_df):
    start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    try:
        # Get the cd_value column
        flattened_df = get_cd_value_column(flattened_df)
        
        # Copy cd_value to Member_ID column
        flattened_df = flattened_df.withColumn("MEMBER_ID", col("cd_value"))
        
        # Adjust Member_ID based on its length
        flattened_df = flattened_df.withColumn(
            "MEMBER_ID",
            when(length(col("MEMBER_ID")) == 9, concat(col("MEMBER_ID"), lit("00")))
            .otherwise(col("MEMBER_ID"))
        )
        
        # Get the values of the 'Member_ID' column and store in a list
        member_ids = flattened_df.select('MEMBER_ID').rdd.flatMap(lambda x: x).collect()
        print(f"Number of Member IDs: {len(member_ids)}")
        
        # Create a single query for all member_ids
        member_ids_str = ', '.join([f"'{member_id}'" for member_id in member_ids if member_id != "Not Available"])
        member_details_query = f"""
        WITH ranked_data AS (
            SELECT  
                SUBSCRIBER_ID || MBR_SFX AS MEMBER_ID,
                COUNTY_NAME,
                STATE,
                AGE_IN_YEARS,
                PRODUCT_LOB,
                FINANCE_LOB,
                CLASS_PLAN_ID,
                GROUP_NUM,
                GROUP_NAME,
                ROW_NUMBER() OVER (PARTITION BY SUBSCRIBER_ID ORDER BY STUDY_PERIOD DESC) AS rn
            FROM ec_sbx_adv_anltcs_prd1.mbrdna_prd.tbl_tgt_mbrdna_dnrmlzd_wide 
            WHERE LEFT(SUBSCRIBER_ID, 9) IN ({member_ids_str})
            OR LEFT(SUBSCRIBER_ID || MBR_SFX, 11) IN ({member_ids_str})
        )
        SELECT 
            ranked_data.MEMBER_ID AS ranked_MEMBER_ID,
            ranked_data.COUNTY_NAME AS ranked_COUNTY_NAME,
            ranked_data.STATE AS ranked_STATE,
            ranked_data.AGE_IN_YEARS AS ranked_AGE_IN_YEARS,
            ranked_data.PRODUCT_LOB AS ranked_PRODUCT_LOB,
            ranked_data.FINANCE_LOB AS ranked_FINANCE_LOB,
            ranked_data.CLASS_PLAN_ID AS ranked_CLASS_PLAN_ID,
            ranked_data.GROUP_NUM AS ranked_GROUP_NUM,
            ranked_data.GROUP_NAME AS ranked_GROUP_NAME
        FROM ranked_data
        WHERE ranked_data.rn = 1
        """
        
        try:
            # Execute the query and get the result as a DataFrame
            member_details_df = spark.sql(member_details_query)
            # log_stage("Snowflake_utils", start_time, "Success", "Executed query for all member_ids")
        except Exception as query_exception:
            # log_stage("Snowflake_utils", start_time, "Failed", f"Query execution failed: {query_exception}")
            return flattened_df
        
        # Create a dictionary from member_details_df for quick lookup
        member_details_dict = {row['ranked_MEMBER_ID']: (row['ranked_COUNTY_NAME'], row['ranked_STATE'], row['ranked_AGE_IN_YEARS'], row['ranked_PRODUCT_LOB'], row['ranked_FINANCE_LOB'], row['ranked_CLASS_PLAN_ID'], row['ranked_GROUP_NUM'], row['ranked_GROUP_NAME']) for row in member_details_df.collect()}
        
        # Join the original DataFrame with the member details DataFrame
        updated_df = flattened_df.join(
            member_details_df,
            (flattened_df['MEMBER_ID'].substr(1, 9) == member_details_df['ranked_MEMBER_ID'].substr(1, 9)) |
            (flattened_df['MEMBER_ID'].substr(1, 11) == member_details_df['ranked_MEMBER_ID'].substr(1, 11)),
            how='left'
        )
        
        # Update the DataFrame with new columns
        updated_df = updated_df.withColumn("MEMBER_ID", col("ranked_MEMBER_ID")) \
                               .withColumn("MEMBER_GEO_COUNTY", col("ranked_COUNTY_NAME")) \
                               .withColumn("MEMBER_STATE", col("ranked_STATE")) \
                               .withColumn("MEMBER_AGE", col("ranked_AGE_IN_YEARS")) \
                               .withColumn("MEMBER_PLAN", col("ranked_PRODUCT_LOB")) \
                               .withColumn("MEMBER_LOB", col("ranked_FINANCE_LOB")) \
                               .withColumn("CLASS_PLAN_ID", col("ranked_CLASS_PLAN_ID"))\
                               .withColumn("GROUP_NUM", col("ranked_GROUP_NUM"))\
                               .withColumn("GROUP_NAME", col("ranked_GROUP_NAME"))\
                               .withColumn("CONVERSATION_DATE_TIME", concat(col("CONVERSATION_START_DATE"), lit(" "), col("CONVERSATION_START_TIME")))
        
        # Drop the additional columns created during the join
        updated_df = updated_df.drop("ranked_MEMBER_ID", "ranked_COUNTY_NAME", "ranked_STATE", "ranked_AGE_IN_YEARS", "ranked_PRODUCT_LOB", "ranked_FINANCE_LOB", "ranked_CLASS_PLAN_ID", "ranked_GROUP_NUM", "ranked_GROUP_NAME")
        
        # Copy cd_value to Member_ID column
        updated_df = updated_df.withColumn("MEMBER_ID", col("cd_value"))

        # Check for None in Member_ID and replace with "Not Available"
        updated_df = updated_df.withColumn(
            "MEMBER_ID", 
            when(col("MEMBER_ID").isNull(), lit("Not Available")).otherwise(col("MEMBER_ID"))
        )
        
        # log_stage("Snowflake_utils", start_time, "Success", "Updated DataFrame with snowflake-related columns")
        print("Updated DataFrame with snowflake-related columns")
        
    except Exception as e:
        # log_stage("Snowflake_utils", start_time, "Failed", f"An error occurred: {e}")
        print(f"An error occurred: {e}")
    
    return updated_df

# COMMAND ----------

# MAGIC %md
# MAGIC For Netezza Fields

# COMMAND ----------

import nzpy
import pandas as pd
import time
from pyspark.sql.functions import col, substring

username = "SVCADBADHDCX"  
pwd = dbutils.secrets.get(scope="scope_dcx_ds", key="PWD-SVCADBADHDCX")

# Connection to Netezza ADH_SBX_CUST360 database
try:
    cust360conn = nzpy.connect(
        user=username,
        password=pwd,
        host='npsexp01.bsc.bscal.com',
        port=5480,
        database="ADH_SBX_CUST360",
        securityLevel=1,
        logLevel=0
    )
except Exception as e:
    print(f"Error connecting to the database: {e}")

def execute_query(member_ids, conversation_times, cust360conn):
    query = generate_query_for_batch(member_ids, conversation_times)
    return pd.read_sql(query, cust360conn)


# Function to generate the query for batch processing
def generate_query_for_batch(member_ids, conversation_times):
    member_ids_str = ' UNION ALL '.join(
        f"SELECT '{id}' AS MEMBER_ID, '{time}' AS CONVERSATION_TIME" 
        for id, time in zip(member_ids, conversation_times)
    )
    query = f"""
    WITH SpecifiedMembers AS (
    {member_ids_str}
    ),
    LatestEvents AS (
    SELECT 
        sm.MEMBER_ID, 
        dgp.DIGITAL_PRFL_ID_1 AS DIGITAL_PROFILE_ID, 
        splunk_mbr.EVENT_DTM AS EVENT_DATE,
        ROW_NUMBER() OVER (PARTITION BY sm.MEMBER_ID ORDER BY splunk_mbr.EVENT_DTM DESC) AS rn
    FROM
        SpecifiedMembers sm
    LEFT JOIN 
        ADH_SBX_CUST360.ADMIN.LU_CIAM_PLNMBR_DIGITAL_PROFILE dgp  
        ON sm.MEMBER_ID = CAST(dgp.SBSCR_ID AS VARCHAR(20))
    LEFT JOIN 
        ADH_SBX_CUST360.ADMIN.ETL_SPLUNK_PING_MEMBER_AUDIT splunk_mbr  
        ON dgp.DIGITAL_PRFL_ID_1 = splunk_mbr.DIGITAL_PRFL_ID
    WHERE
        splunk_mbr.EVENT_DTM < sm.CONVERSATION_TIME
    )
    SELECT 
        MEMBER_ID, 
        DIGITAL_PROFILE_ID, 
        EVENT_DATE AS LAST_ONLINE,
        CASE 
            WHEN DIGITAL_PROFILE_ID IS NOT NULL AND DIGITAL_PROFILE_ID != '' THEN 'Yes'
            WHEN DIGITAL_PROFILE_ID IS NULL OR DIGITAL_PROFILE_ID = '' OR DIGITAL_PROFILE_ID = ' ' THEN 'No'
            ELSE 'No'
        END AS MEMBER_REGISTERED
    FROM 
        LatestEvents
    WHERE 
        rn = 1
    """
    return query

def batch_query(ids, times, batch_size=1000, retries=3):
    """Execute the query in batches with retry mechanism."""
    results = []
    for i in range(0, len(ids), batch_size):
        batch_ids = ids[i:i+batch_size]
        batch_times = times[i:i+batch_size]
        attempt = 0
        while attempt < retries:
            try:
                print(f"Executing batch query for batch {i//batch_size + 1}, attempt {attempt + 1}...")
                batch_results = execute_query(batch_ids, batch_times, cust360conn)
                results.append(batch_results)
                break
            except Exception as e:
                print(f"Error executing query for batch {i//batch_size + 1}, attempt {attempt + 1}: {e}")
                attempt += 1
                if attempt == retries:
                    print(f"Failed to execute query for batch {i//batch_size + 1} after {retries} attempts.")
    return pd.concat(results, ignore_index=True)

def update_member_info_with_netezza(df, batch_size=1000):
    start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

    try:
        # Convert Spark DataFrame to Pandas DataFrame if necessary
        if not isinstance(df, pd.DataFrame):
            df = df.toPandas()
            print("Converted Spark DataFrame to Pandas DataFrame")

        if 'MEMBER_ID' not in df.columns or 'CONVERSATION_DATE_TIME' not in df.columns:
            print("DataFrame must contain 'MEMBER_ID' and 'CONVERSATION_DATE_TIME' columns")
            return df

        # Convert Member_ID to string and trim to the first 9 digits for those that are not 'Not Available'
        df['MEMBER_ID'] = df['MEMBER_ID'].apply(lambda x: str(x)[:9] if x != 'Not Available' else x)

        member_ids = df['MEMBER_ID'].dropna().tolist()
        conversation_times = df['CONVERSATION_DATE_TIME'].dropna().tolist()
        
        if not member_ids:
            print("No valid subscriber IDs found in the DataFrame")
            return df

        # Separate 'Not Available' member IDs
        not_available_ids = [id for id in member_ids if id == 'Not Available']
        valid_member_ids = [id for id in member_ids if id != 'Not Available']

        # Initialize columns for 'Not Available' member IDs
        df.loc[df['MEMBER_ID'] == 'Not Available', 'MEMBER_REGISTERED'] = 'Not Available'
        df.loc[df['MEMBER_ID'] == 'Not Available', 'MEMBER_LAST_ONLINE'] = 'Not Available'

        if valid_member_ids:
            try:
                update_df = batch_query(valid_member_ids, conversation_times, batch_size)
                print("Executed batch query successfully")
            except Exception as e:
                print(f"Error during batch query execution: {e}")
                return df

            # Format the Last_Online column
            try:
                update_df['LAST_ONLINE'] = pd.to_datetime(update_df['LAST_ONLINE']).dt.strftime('%Y-%m-%d %H:%M:%S')
                print("Formatted Last_Online column successfully")
            except Exception as e:
                print(f"Error formatting Last_Online column: {e}")
                return df

            # Create dictionaries for quick lookup
            last_online_dict = update_df.set_index('MEMBER_ID')['LAST_ONLINE'].to_dict()
            member_registered_dict = update_df.set_index('MEMBER_ID')['MEMBER_REGISTERED'].to_dict()

            # Update the original dataframe with the new information
            def update_info(member_id):
                if member_id in not_available_ids:
                    return 'Not Available', 'Not Available'
                else:
                    member_registered = member_registered_dict.get(member_id, 'No')
                    last_online = last_online_dict.get(member_id, None)
                    if member_registered is None or member_registered == '':
                        member_registered = 'No'
                    return member_registered, last_online

            df['MEMBER_REGISTERED'], df['MEMBER_LAST_ONLINE'] = zip(*df['MEMBER_ID'].map(update_info))

        print("Updated DataFrame with new columns")

    except Exception as e:
        print(f"An error occurred: {e}")

    return df

# COMMAND ----------

# MAGIC %md
# MAGIC Adding Dummy Values (Random) for Netezza fields

# COMMAND ----------

def add_dummy_values(flattened_df):
    start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    try:
        # Define a UDF to generate random "Last_Online" timestamp
        def generate_last_online(conversation_start):
            if conversation_start is not None:
                # Parse the string to a datetime object
                conversation_start_dt = datetime.strptime(conversation_start, '%Y-%m-%d %H:%M:%S')
                hours_back = random.choice([1, 2, 5, 7])
                last_online = conversation_start_dt - timedelta(hours=hours_back)
                return last_online
            return None
        
        generate_last_online_udf = udf(generate_last_online, TimestampType())
        # log_stage("Netezza(dummy)-Define UDF", start_time, "Success", "Defined UDF to generate random Last_Online timestamp")
        
        # Define window specification
        window_spec = Window.partitionBy("id").orderBy("id")
        
        # Add columns with consistent values for duplicate "id"
        flattened_df = flattened_df.withColumn(
            "MEMBER_LAST_ONLINE", 
            first(
                when(col("MEMBER_ID").isNotNull(), 
                     date_format(generate_last_online_udf(col("CONVERSATION_DATE_TIME")), "yyyy-MM-dd HH:mm:ss")
                ).otherwise(None)
            ).over(window_spec)
        )
        # log_stage("Netezza(dummy)-Add Last_Online Column", start_time, "Success", "Added Last_Online column with consistent values")
        
        flattened_df = flattened_df.withColumn(
            "MEMBER_REGISTERED", 
            when(col("MEMBER_ID").isNotNull(), "Yes").otherwise("No")
        )
        # log_stage("Netezza(dummy)-Add Member_Registered Column", start_time, "Success", "Added Member_Registered column with consistent values")
        
    except Exception as e:
        print(f"An error occurred in add_dummy_values: {e}")
        # log_stage("Netezza(dummy)-Add Dummy Values", start_time, "Failed", f"An error occurred in add_dummy_values: {e}")
    
    return flattened_df

# COMMAND ----------

# MAGIC %md
# MAGIC Add dummy values for NPS and CSAT (Added call if VERINT_CONNECTION= OFF)

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.functions import lit

def add_dummy_for_verint(flattened_df):
    start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    try:
        # Check if the input is a Spark DataFrame
        if not isinstance(flattened_df, DataFrame):
            flattened_df = spark.createDataFrame(flattened_df)
            # log_stage("Verint_utils", start_time, "Success", "Converted Spark DataFrame to Pandas DataFrame")
            
        # Add columns with consistent values for duplicate "id"
        flattened_df = flattened_df.withColumn("CALL_SATISFACTION_SCORE", lit("Not Available"))
        # log_stage("Verint_utils", start_time, "Success", "Updated DataFrame with dummy values")
        
    except Exception as e:
        print(f"An error occurred in add_dummy_for_verint: {e}")
        # log_stage("Verint_utils", start_time, "Failed", f"Failed to update DataFrame{e}")
    
    return flattened_df

# COMMAND ----------

# MAGIC %md
# MAGIC For NPS

# COMMAND ----------

import nzpy
import pandas as pd
import time
from pyspark.sql.functions import col, substring

username = "SVCADBADHDCX"  
pwd = dbutils.secrets.get(scope="scope_dcx_ds", key="PWD-SVCADBADHDCX")

# Connection to Netezza ADH_SBX_CUST360 database
try:
    cust360conn = nzpy.connect(
        user=username,
        password=pwd,
        host='npsexp01.bsc.bscal.com',
        port=5480,
        database="ADH_SBX_CUST360",
        securityLevel=1,
        logLevel=0
    )
except Exception as e:
    print(f"Error connecting to the database: {e}")

def execute_query_nps(sub_ids, conversation_times, cust360conn):
    conditions = " OR ".join([f"(SUB_ID = '{sub_id}' AND SURVEY_DT >= TO_TIMESTAMP('{conv_time}', 'YYYY-MM-DD HH24:MI:SS'))" for sub_id, conv_time in zip(sub_ids, conversation_times)])
    nps_query = f"""
        WITH ranked_data AS (
            SELECT 
                SUB_ID, 
                NPS_SCORE, 
                NPS_GROUP, 
                SURVEY_DT AS SURVEY_DATE,
                ROW_NUMBER() OVER (PARTITION BY SUB_ID ORDER BY SURVEY_DT ASC) AS rn
            FROM 
                ADH_SBX_CUST360.ADMIN.DASH_NPS_FINAL 
            WHERE 
                {conditions}
        )
        SELECT 
            SUB_ID, 
            NPS_SCORE, 
            NPS_GROUP, 
            SURVEY_DATE
        FROM 
            ranked_data
        WHERE 
            rn = 1
    """
    return pd.read_sql(nps_query, cust360conn)

def batch_query_nps(ids, times, batch_size=1000, retries=3):
    """Execute the query in batches with retry mechanism."""
    results = []
    for i in range(0, len(ids), batch_size):
        batch_ids = ids[i:i+batch_size]
        batch_times = times[i:i+batch_size]
        attempt = 0
        while attempt < retries:
            try:
                print(f"Executing batch query for batch {i//batch_size + 1}, attempt {attempt + 1}...")
                batch_results = execute_query_nps(batch_ids, batch_times, cust360conn)
                results.append(batch_results)
                break
            except Exception as e:
                print(f"Error executing query for batch {i//batch_size + 1}, attempt {attempt + 1}: {e}")
                attempt += 1
                if attempt == retries:
                    print(f"Failed to execute query for batch {i//batch_size + 1} after {retries} attempts.")
    return pd.concat(results, ignore_index=True)

def update_member_info_with_netezza_nps(df, batch_size=1000):
    start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

    try:
        # Convert Spark DataFrame to Pandas DataFrame if necessary
        if not isinstance(df, pd.DataFrame):
            df = df.toPandas()
            print("Converted Spark DataFrame to Pandas DataFrame")

        if 'MEMBER_ID' not in df.columns or 'CONVERSATION_DATE_TIME' not in df.columns:
            print("DataFrame must contain 'MEMBER_ID' and 'CONVERSATION_DATE_TIME' columns")
            return df

        # Convert Member_ID to string and trim to the first 9 digits for those that are not 'Not Available'
        df['MEMBER_ID'] = df['MEMBER_ID'].apply(lambda x: str(x)[:9] if x != 'Not Available' else x)

        member_ids = df['MEMBER_ID'].dropna().tolist()
        conversation_times = df['CONVERSATION_DATE_TIME'].dropna().tolist()
        
        if not member_ids:
            print("No valid subscriber IDs found in the DataFrame")
            return df

        # Separate 'Not Available' member IDs
        not_available_ids = [id for id in member_ids if id == 'Not Available']
        valid_member_ids = [id for id in member_ids if id != 'Not Available']

        # Initialize columns for 'Not Available' member IDs
        df.loc[df['MEMBER_ID'] == 'Not Available', 'MEMBER_NPS'] = 'Not Available'
        df.loc[df['MEMBER_ID'] == 'Not Available', 'SURVEY_DATE'] = 'Not Available'
        df.loc[df['MEMBER_ID'] == 'Not Available', 'NPS_GROUP'] = 'Not Available'

        if valid_member_ids:
            try:
                update_df = batch_query_nps(valid_member_ids, conversation_times, batch_size)
                print("Executed batch query successfully")
            except Exception as e:
                print(f"Error during batch query execution: {e}")
                return df

            # Format the SURVEY_DATE column
            try:
                update_df['SURVEY_DATE'] = pd.to_datetime(update_df['SURVEY_DATE']).dt.strftime('%Y-%m-%d %H:%M:%S')
                print("Formatted SURVEY_DATE column successfully")
            except Exception as e:
                print(f"Error formatting SURVEY_DATE column: {e}")
                return df

            # Create dictionaries for quick lookup
            nps_score_dict = update_df.set_index('SUB_ID')['NPS_SCORE'].to_dict()
            survey_date_dict = update_df.set_index('SUB_ID')['SURVEY_DATE'].to_dict()
            nps_group_dict = update_df.set_index('SUB_ID')['NPS_GROUP'].to_dict()

            # Update the original dataframe with the new information
            def update_info(member_id):
                if member_id in not_available_ids:
                    return 'Not Available', 'Not Available', 'Not Available'
                else:
                    nps_score = nps_score_dict.get(member_id, None)
                    survey_date = survey_date_dict.get(member_id, None)
                    nps_group = nps_group_dict.get(member_id, None)
                    return nps_score, survey_date, nps_group

            df['MEMBER_NPS'], df['SURVEY_DATE'], df['NPS_GROUP'] = zip(*df['MEMBER_ID'].map(update_info))

        print("Updated DataFrame with new columns")

    except Exception as e:
        print(f"An error occurred: {e}")

    return df

# COMMAND ----------

# MAGIC %md
# MAGIC For IFP_Metal INFO

# COMMAND ----------

# Install the required packages
%pip install --upgrade "jaydebeapi" "pandas" "openpyxl"

import jaydebeapi
import pandas as pd



def update_ifp_metal_column(df):

        # Copy the Oracle JDBC driver to the correct location
    dbutils.fs.cp(
        "dbfs:/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/drivers/ojdbc8.jar",
        "dbfs:/FileStore/jars/",
    )

    # Add the Oracle JDBC driver to the Spark session
    spark.sparkContext.addFile("/dbfs/FileStore/jars/ojdbc8.jar")
    spark._jsc.addJar("/dbfs/FileStore/jars/ojdbc8.jar")

    # Database credentials
    username = "SVCORAADBCALLINT"
    pwd = dbutils.secrets.get(scope="scope_dcx_ds", key="PWD-SVCORAADBCALLINT")
    jdbc_url = "jdbc:oracle:thin:@fcrp01a-scan.bsc.bscal.com:12521/FCRP01A"
    driver_class = "oracle.jdbc.driver.OracleDriver"
    jar_path = "/dbfs/FileStore/jars/ojdbc8.jar"

    # Check for CLASS_PLAN_ID column

    if 'CLASS_PLAN_ID' not in df.columns:
        return df

    # Get the unique CLASS_PLAN_ID values
    cd_values = df.select('CLASS_PLAN_ID').distinct().rdd.flatMap(lambda x: x).collect()

    # Function to process each batch
    def process_batch(batch_cd_values: list):
        cd_values_str = ', '.join([f"'{cd_value}'" for cd_value in batch_cd_values])
        
        query = f"""
            WITH ranked_data AS (
               SELECT DISTINCT 
                PLDS_DESC,
                CSPI_ID AS ranked_CLASS_PLAN_ID,
                CASE
                    WHEN PLDS_DESC LIKE '%Platinum%' THEN 'Platinum'
                    WHEN PLDS_DESC LIKE '%Gold%' THEN 'Gold'
                    WHEN PLDS_DESC LIKE '%Silver%' THEN 'Silver'
                    WHEN PLDS_DESC LIKE '%Bronze%' THEN 'Bronze'
                    ELSE 'Not Available'
                END AS METAL
            FROM CMC_PLDS_PLAN_DESC
            WHERE CSPI_ID IN ({cd_values_str})
            )
            SELECT 
                ranked_CLASS_PLAN_ID AS CLASS_PLAN_ID,
                METAL AS PLAN_METAL
            FROM ranked_data
        """
        
        # Connect to the Oracle database using jaydebeapi
        try:
            conn = jaydebeapi.connect(driver_class, jdbc_url, [username, pwd], jar_path)
            curs = conn.cursor()
            curs.execute(query)
            rows = curs.fetchall()
            columns = [column[0] for column in curs.description]
            curs.close()
            conn.close()
            result_df = pd.DataFrame(rows, columns=columns)
            return result_df
        except Exception as e:
            print(f"Connection failed: {e}")
            return pd.DataFrame()

    # Process in batches of 1000
    batch_size = 1000
    num_batches = (len(cd_values) + batch_size - 1) // batch_size

    result_dfs = []
    for i in range(num_batches):
        batch_cd_values = cd_values[i * batch_size: (i + 1) * batch_size]
        result_dfs.append(process_batch(batch_cd_values))

    # Combine all result DataFrames
    combined_result_df = pd.concat(result_dfs, ignore_index=True)

    # Convert the result DataFrame to a Spark DataFrame
    result_spark_df = spark.createDataFrame(combined_result_df)

    # Merge the result with the original DataFrame
    updated_df = df.join(result_spark_df, on='CLASS_PLAN_ID', how='left')

    return updated_df

# COMMAND ----------

# MAGIC %md
# MAGIC Add dummy values with NA

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.functions import lit

def dummy_with_na_values(flattened_df):
    try:
        # Check if the input is a Spark DataFrame
        if not isinstance(flattened_df, DataFrame):
            flattened_df = spark.createDataFrame(flattened_df)
        
        # Set all specified columns to "NA"
        flattened_df = flattened_df.withColumn("MEMBER_LAST_ONLINE", lit("Not Available")) \
                                   .withColumn("MEMBER_REGISTERED", lit("Not Available")) \
                                   .withColumn("CALL_SATISFACTION_SCORE", lit("Not Available")) \
                                   .withColumn("MEMBER_NPS", lit("Not Available")) \
                                   .withColumn("MEMBER_TENURE", lit("Not Available"))
        
    except Exception as e:
        print(f"An error occurred in dummy_with_na_values: {e}")
    
    return flattened_df

# COMMAND ----------

# MAGIC %md
# MAGIC For Verint (MS SQL) Fields

# COMMAND ----------

from pyspark.sql import functions as F
import pyodbc
import pandas as pd

def create_connection(host, port, database, username, password):
    connection_string = (
        f'DRIVER={{ODBC Driver 17 for SQL Server}};'
        f'SERVER={host},{port};'
        f'DATABASE={database};'
        f'UID={username};'
        f'PWD={password};'
        f'Connection Timeout=30;'
    )
    return pyodbc.connect(connection_string)

def update_call_satisfaction_score(df):
    # Check if 'Member_ID' column exists in the DataFrame
    if 'MEMBER_ID' not in df.columns:
        raise ValueError("The DataFrame does not contain the 'MEMBER_ID' column.")
    
    # Connection details
    USERNAME = "svc_sql_databricks_dcx"
    PASSWORD = dbutils.secrets.get(scope="scope_dcx_ds", key="PWD-SVCSQLDATABRICKSDCXVERINT")
    HOST = "wsql40532p.bsc.bscal.com"
    PORT = 50101
    DATABASE = "BPWAREHOUSEDB"

    try:
        # Establish connection
        conn = create_connection(HOST, PORT, DATABASE, USERNAME, PASSWORD)
        
        # Define the query to retrieve needed data
        derived_query = """
        WITH DerivedCTE AS (
            SELECT 
                `INTERACTIONENDDATESSTZ` AS `DT`,
                cast(`INTERACTIONENDDATESSTZ` as Date) as Row_date,
                'English' AS SurveyLanguage,
                `FACTSURVEYID`,
                CASENUMBER,
                UCID,
                ANI,
                TFN,
                MemberID,
                CONCAT(LEFT(MemberID, 9), 0, RIGHT(MemberID, 2)) AS MEMBERID_12,
                EDUID,
                AGENTLOGINID,
                `Name`,
                LANID,
                BSCEmpID,
                Email,
                Organization_Name,
                Supervisor,
                SUP_LANID,
                Manager,
                MNGR_LANID,
                CASE 
                    WHEN `Location` IS NULL OR `Location` = '' THEN 'Unknown' 
                    WHEN `Location` = 'Black Canyon' OR `Location` = 'TTECH' OR `Location` = 'Manila' THEN 'Vendors' 
                    ELSE 'BSC'
                END AS `Site`,
                `Location`,
                IMODIFIED,
                ISDELETED,
                RESPONSESTARTDATEGMT,
                EXTERNALEMPIDENT,
                CASE 
                    WHEN `Did the Customer Service Agent resolve your inquiry?` < 0 THEN NULL 
                    ELSE `Did the Customer Service Agent resolve your inquiry?`
                END AS `Issue Resolved`,
                CASE
                    WHEN `Did the Customer Service Agent resolve your inquiry?` = 2 THEN 0
                    WHEN `Did the Customer Service Agent resolve your inquiry?` = 1 THEN 1
                    ELSE NULL
                END AS `IR Top Box`,
                CASE 
                    WHEN `Based upon your experience today, how satisfied are you with the last Customer Service Agent you spoke with?` < 0 THEN NULL 
                    ELSE `Based upon your experience today, how satisfied are you with the last Customer Service Agent you spoke with?`
                END AS `Agent CSAT`,
                CASE 
                    WHEN `Based upon your experience today, how satisfied are you with the last Customer Service Agent you spoke with?` >= 9 THEN 1
                    WHEN `Based upon your experience today, how satisfied are you with the last Customer Service Agent you spoke with?` < 9 
                    AND `Based upon your experience today, how satisfied are you with the last Customer Service Agent you spoke with?` >= 0 THEN 0
                    ELSE NULL
                END AS `Agent Top Box`,
                CASE 
                    WHEN `With respect to your overall call experience today, how satisfied are you with the Customer Service Call Center?` < 0 THEN NULL 
                    ELSE `With respect to your overall call experience today, how satisfied are you with the Customer Service Call Center?`
                END AS `Member CSAT`,
                CASE 
                    WHEN `With respect to your overall call experience today, how satisfied are you with the Customer Service Call Center?` >= 9 THEN 1
                    WHEN `With respect to your overall call experience today, how satisfied are you with the Customer Service Call Center?` < 9 
                    AND `With respect to your overall call experience today, how satisfied are you with the Customer Service Call Center?` >= 0 THEN 0
                    ELSE NULL
                END AS `Member Top Box`,
                CASE 
                    WHEN `What is the ONE thing we can do to improve your experience?` < 0 THEN NULL 
                    ELSE `What is the ONE thing we can do to improve your experience?`
                END AS `Recording`,
                CASE 
                    WHEN `We’re sorry to hear that.  Would you like a Customer Service Representative to contact you for additional assistance?` < 0 THEN NULL 
                    ELSE `We’re sorry to hear that.  Would you like a Customer Service Representative to contact you for additional assistance?`
                END AS `CAll Back`
            FROM
                (SELECT 
                    c.`INTERACTIONENDDATESSTZ`,
                    b.QUESDEFAULTTEXTINTRO,
                    a.`ANSWER`,
                    a.`FACTSURVEYID`,
                    c.CASENUMBER,
                    CASE 
                        WHEN CHARINDEX('_', c.CASENUMBER) > 0 and substring(CONVERT(VARCHAR(10),c.RESPONSESTARTDATEGMT,120),1,10) < '2022-10-20' THEN SUBSTRING(c.CASENUMBER, 0, CHARINDEX('_', c.CASENUMBER, 0))
                        WHEN substring(CONVERT(VARCHAR(10),c.RESPONSESTARTDATEGMT,120),1,10) < '2022-10-20' THEN LEFT(c.CASENUMBER, 16)  
                        ELSE NULL
                    END AS UCID,
                    CASE 
                        WHEN c.CASENUMBER LIKE 'Anonymous%' and substring(CONVERT(VARCHAR(10),c.RESPONSESTARTDATEGMT,120),1,10) >= '2022-10-20' THEN substring(c.CASENUMBER, 1, 9) 
                        WHEN substring(CONVERT(VARCHAR(10),c.RESPONSESTARTDATEGMT,120),1,10) >= '2022-10-20' and LEN(c.CASENUMBER) >= 92 THEN substring(c.CASENUMBER, 1, 10)
                        WHEN CHARINDEX('_', c.CASENUMBER)-17 > 0 THEN SUBSTRING(c.CASENUMBER, 17, CHARINDEX('_', c.CASENUMBER)-17)
                        ELSE RIGHT(LEFT(c.CASENUMBER,27),11)
                    END AS ANI,
                    CASE 
                        WHEN c.CASENUMBER LIKE 'Anonymous%' and substring(CONVERT(VARCHAR(10),c.RESPONSESTARTDATEGMT,120),1,10) >= '2022-10-20' THEN substring(c.CASENUMBER, 43, 10) 
                        WHEN substring(CONVERT(VARCHAR(10),c.RESPONSESTARTDATEGMT,120),1,10) >= '2022-10-20' and LEN(c.CASENUMBER) >= 92 THEN substring(c.CASENUMBER, 44, 10)
                        WHEN CHARINDEX('_', c.CASENUMBER)+ 1 > 0 THEN SUBSTRING(c.CASENUMBER, CHARINDEX('_', c.CASENUMBER)+ 1, 10)
                        ELSE RIGHT(LEFT(c.CASENUMBER,38),11)
                    END AS TFN,
                    CASE 
                        WHEN c.CASENUMBER LIKE 'Anonymous%' and substring(CONVERT(VARCHAR(10),c.RESPONSESTARTDATEGMT,120),1,10) >= '2022-10-20' THEN substring(c.CASENUMBER, 58, 11) 
                        WHEN substring(CONVERT(VARCHAR(10),c.RESPONSESTARTDATEGMT,120),1,10) >= '2022-10-20' and LEN(c.CASENUMBER) >= 92 THEN substring(c.CASENUMBER, 59, 11)
                        WHEN CHARINDEX('_', c.CASENUMBER)+ 11 > 0 THEN SUBSTRING(c.CASENUMBER, CHARINDEX('_', c.CASENUMBER)+ 11, 11)
                        ELSE RIGHT(LEFT(c.CASENUMBER, 49), 11)
                    END AS MemberID,
                    CASE 
                        WHEN c.CASENUMBER LIKE 'Anonymous%' and substring(CONVERT(VARCHAR(10),c.RESPONSESTARTDATEGMT,120),1,10) >= '2022-10-20' THEN substring(c.CASENUMBER, 10, 32) 
                        WHEN substring(CONVERT(VARCHAR(10),c.RESPONSESTARTDATEGMT,120),1,10) >= '2022-10-20' and LEN(c.CASENUMBER) >= 92 THEN substring(c.CASENUMBER, 11, 32) 
                        WHEN LEN(c.CASENUMBER) - 31 > 0 THEN SUBSTRING(c.CASENUMBER, LEN(c.CASENUMBER) - 31, 32)
                        ELSE RIGHT(LEFT(c.CASENUMBER, 81), 31)
                    END AS EDUID,
                    c.AGENTLOGINID,
                    P.LASTNAME + ', ' + P.FIRSTNAME AS `Name`,
                    LOWER(BP.UserName) AS LANID,
                    EA.EMPLOYEENUMBER AS BSCEmpID,
                    LOWER(pc.`Value`) AS Email,
                    org.NAME AS Organization_Name,
                    PS.LASTNAME + ', ' + PS.FIRSTNAME AS Supervisor,
                    LOWER(BPS.UserName) AS SUP_LANID,
                    PM.LASTNAME + ', ' + PM.FIRSTNAME AS Manager,
                    LOWER(BPM.UserName) AS MNGR_LANID,
                    loc.Location,
                    a.IMODIFIED,
                    a.ISDELETED,
                    c.RESPONSESTARTDATEGMT,
                    EDS.EXTERNALEMPIDENT
                FROM `BPWAREHOUSEDB`.`dbo`.`FACTSURVEY` c
                LEFT JOIN `BPWAREHOUSEDB`.`dbo`.`FACTSURVEYANSWER` a on c.ID = a.FACTSURVEYID
                LEFT JOIN `BPWAREHOUSEDB`.`dbo`.`DIMQUESTION` b on a.DIMQUESTIONID = b.ID
                LEFT JOIN `BPWAREHOUSEDB`.`dbo`.`DIMSURVEY` e on c.DIMSURVEYID = e.ID
                LEFT JOIN `BPMainDB`.`dbo`.DIMEREMPLOYEE DIMEMP ON c.DIMEREMPLOYEEID = DIMEMP.ID
                LEFT JOIN `BPMainDB`.`dbo`.EMPLOYEEAM EA ON DIMEMP.EMPLOYEEBUSKEY = EA.ID
                LEFT JOIN `BPMainDB`.`dbo`.EMPLOYEEDATASOURCE EDS ON EA.ID = EDS.EMPLOYEEID AND EDS.DATASOURCEID = -24001
                LEFT JOIN `BPMainDB`.`dbo`.BPUser BP ON EA.ID = BP.EMPLOYEEID  
                LEFT JOIN `BPMainDB`.`dbo`.PERSON P on EA.PERSONID=P.ID  
                LEFT JOIN `BPMainDB`.`dbo`.PERSONCONTACT pc on pc.PersonID=P.ID AND pc.contactmethodid=-9002
                LEFT JOIN `BPMainDB`.`dbo`.SUPERVISOR SUP on DIMEMP.EMPLOYEEBUSKEY=SUP.EMPLOYEEID AND c.`INTERACTIONENDDATESSTZ`
                    BETWEEN CAST(SUP.STARTTIME AS DATE) AND CAST(COALESCE(SUP.ENDTIME,GETDATE()) AS DATE) 
                LEFT JOIN `BPMainDB`.`dbo`.EMPLOYEEAM SUPS on SUP.SUPERVISOREMPLOYEEID = SUPS.ID
                LEFT JOIN `BPMainDB`.`dbo`.BPUser BPS ON SUPS.ID = BPS.EMPLOYEEID  
                LEFT JOIN `BPMainDB`.`dbo`.PERSON PS on SUPS.PERSONID = PS.ID
                LEFT JOIN `BPMainDB`.`dbo`.EmployeeTeamLead ETL on DIMEMP.EMPLOYEEBUSKEY=ETL.EMPLOYEEID AND c.`INTERACTIONENDDATESSTZ` 
                    BETWEEN CAST(ETL.STARTTIME AS DATE) AND CAST(COALESCE(ETL.ENDTIME,GETDATE()) AS DATE)
                LEFT OUTER JOIN `BPMainDB`.`dbo`.EMPLOYEEAM MNG on ETL.TEAMLEADEMPLOYEEID = MNG.ID
                LEFT OUTER JOIN `BPMainDB`.`dbo`.BPUser BPM ON MNG.ID = BPM.EMPLOYEEID  
                LEFT OUTER JOIN `BPMainDB`.`dbo`.PERSON PM on MNG.PERSONID = PM.ID
                LEFT OUTER JOIN `BPMainDB`.`dbo`.WORKRESOURCEJOBTITLE wrj on DIMEMP.EMPLOYEEBUSKEY = wrj.WORKRESOURCEID and c.`INTERACTIONENDDATESSTZ` 
                    BETWEEN CAST(wrj.STARTTIME AS DATE) and CAST(COALESCE(wrj.EndTime,GETDATE()) AS DATE)
                LEFT OUTER JOIN (SELECT uda.PRIMARYOBJECTID AS EmpId, uda.FREETEXTVALUE AS `Location`               
                    FROM `BPMainDB`.`dbo`.QueueAttributedefinition qad INNER JOIN `BPMainDB`.`dbo`.Userdefinedattributes uda on uda.UDADEFINITIONID=QAD.ID     
                    WHERE qad.MODULEID=1  AND qad.`Name` = 'Location' ) loc ON DIMEMP.EMPLOYEEBUSKEY = loc.EmpId
                LEFT OUTER JOIN `BPMainDB`.`dbo`.WORKRESOURCEORGANIZATION wro on wro.WORKRESOURCEID=DIMEMP.EMPLOYEEBUSKEY and c.`INTERACTIONENDDATESSTZ`
                    BETWEEN CAST(wro.STARTTIME AS DATE) and CAST(COALESCE(wro.EndTime,GETDATE()) AS DATE)
                INNER JOIN `BPMainDB`.`dbo`.Organization Org on Org.ID=wro.ORGANIZATIONID 
                LEFT OUTER JOIN (SELECT EDS.EMPLOYEEID, EDS.ExternalEmpIdent AS ACDLogIn FROM `BPMainDB`.`dbo`.EMPLOYEEDATASOURCE EDS 
                    INNER JOIN `BPMainDB`.`dbo`.DataSource DS on DS.ID=EDS.datasourceID AND DS.Name = 'BSC Phones') ACD ON  EA.ID = ACD.EMPLOYEEID  
                WHERE c.INTERACTIONENDDATESSTZ >=  DATEADD(month, DATEDIFF(month, 0, GETDATE()) - 13, 0)
                AND TITLE IN ('Customer Experience Member Services', 'Customer Experience Member Service 2023')
                AND c.DIMSURVEYID IN ( '3', '6', '17','18')
            ) AS D
            PIVOT (
                MAX(ANSWER)
                FOR QUESDEFAULTTEXTINTRO IN 
                (
                    `Did the Customer Service Agent resolve your inquiry?`, 
                    `Based upon your experience today, how satisfied are you with the last Customer Service Agent you spoke with?`,
                    `With respect to your overall call experience today, how satisfied are you with the Customer Service Call Center?`,
                    `What is the ONE thing we can do to improve your experience?`,
                    `We’re sorry to hear that.  Would you like a Customer Service Representative to contact you for additional assistance?` 
                )
            ) AS P
        ),
        RankedCTE AS (
            SELECT 
                MEMBERID_12, 
                `Member CSAT`,
                `DT`,
                ROW_NUMBER() OVER (PARTITION BY MEMBERID_12 ORDER BY `DT` DESC) AS row_num
            FROM DerivedCTE
        )
        SELECT MEMBERID_12, `Member CSAT`
        FROM RankedCTE
        WHERE row_num = 1
        """
        
        # Execute the query and get the result as a pandas DataFrame
        derived_df = pd.read_sql(derived_query, conn)
        
        # Convert pandas DataFrame to Spark DataFrame
        derived_spark_df = spark.createDataFrame(derived_df)
        
        # Join the original DataFrame with the derived DataFrame on Member_ID and MEMBERID_12
        updated_df = df.join(derived_spark_df, df.MEMBER_ID == derived_spark_df.MEMBERID_12, how='left') \
                       .withColumn('CALL_SATISFACTION_SCORE', F.coalesce(F.col('Member CSAT'), F.lit("Not available"))) \
                       .drop('MEMBERID_12', 'Member CSAT')
        
        return updated_df

    except Exception as e:
        print(f"An error occurred: {e}")
        return df

# COMMAND ----------

# MAGIC %md
# MAGIC Updated delta table method

# COMMAND ----------

def update_delta_table(df, CATALOG_NAME, SCHEMA_NAME, TABLE_NAME):
    '''
    Function to update delta table

    Args:
    df (DataFrame): dataframe to load into delta table
    CATALOG_NAME: catalog name accessed from config notebook
    SCHEMA_NAME: schema name accessed from config notebook
    TABLE_NAME: table name accessed from config notebook

    Returns:
    status of update operation
    '''
    spark.sql(f"USE CATALOG {CATALOG_NAME}")
    spark.sql(f"USE SCHEMA {SCHEMA_NAME}")
    
    try:
        if isinstance(df, pd.DataFrame):
            df = spark.createDataFrame(df)
        
        if spark.catalog.tableExists(f"{CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}"):
            df.write.format("delta")\
                .mode("append")\
                .option("overwriteSchema", "True")\
                .option("mergeSchema", "True")\
                .saveAsTable(f"{CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}")
            return f"successfully updated {CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}"
        else:
            print(f"Table doesn't exist. Creating {CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME} table")
            df.write.format("delta")\
                .saveAsTable(f"{CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}")
            return f"created new table {CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}"
    except Exception as e:
        print(f"Error updating delta table: {e}")


# COMMAND ----------

# MAGIC %md
# MAGIC Initialize Spark Schema

# COMMAND ----------

import json
import os
from pyspark.sql import SparkSession


from concurrent.futures import ThreadPoolExecutor, as_completed

# COMMAND ----------

def initialize_spark(app_name: str = "FlattenedJSONSchema") -> SparkSession:
    """
    Initializes and returns a Spark session with Delta Lake support.
    """
    spark = SparkSession.builder \
        .appName(app_name) \
        .master("local[*]") \
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
        .config("spark.jars.packages", "io.delta:delta-core_2.12:2.1.0") \
        .getOrCreate()
    return spark

# COMMAND ----------

# MAGIC %md
# MAGIC Flatten_Json  Method

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.functions import explode, col, lit, coalesce
from pyspark.sql.types import StringType, DoubleType, LongType, IntegerType, FloatType

def flatten_json(df: DataFrame) -> DataFrame:
    """
    Flattens the classified_category array from the JSON data into individual records.
    
    Args:
    df (DataFrame): Input DataFrame with nested JSON structure.
    
    Returns:
    DataFrame: Flattened DataFrame.
    """
    try:
        # Explode the classified_category array
        df = df.withColumn("classified_category", explode(col("cii_output.overall_level.call_driver_hierarchy.classified_category")))
    except Exception as e:
        print(f"Error flattening JSON: {e}")
        return df
    
    # Add missing columns with default values if they do not exist
    columns_to_add = ["CD10", "CD8", "CD48", "CD93", "CD6"]
    for column in columns_to_add:
        if f"cii_output.info.source_metadata.{column}" not in df.columns:
            df = df.withColumn(f"cii_output.info.source_metadata.{column}", lit(""))
    
    # Select the required fields and flatten the structure
    flattened_df = df.select(
        col("cii_output.info.id").alias("ID").cast(StringType()),
        col("cii_output.info.conversation_filename").alias("CONVERSATION_FILENAME").cast(StringType()),
        col("cii_output.info.conversation_length_sec").alias("CONVERSATION_LENGTH_SEC").cast(DoubleType()),
        col("cii_output.info.conversation_language").alias("CONVERSATION_LANGUAGE").cast(StringType()),
        col("cii_output.info.conversation_start_date").alias("CONVERSATION_START_DATE").cast(StringType()),
        col("cii_output.info.conversation_end_date").alias("CONVERSATION_END_DATE").cast(StringType()),
        col("cii_output.info.conversation_start_time").alias("CONVERSATION_START_TIME").cast(StringType()),
        col("cii_output.info.conversation_end_time").alias("CONVERSATION_END_TIME").cast(StringType()),
        col("cii_output.info.conversation_processed_date").alias("CONVERSATION_PROCESSED_DATE").cast(StringType()),
        col("cii_output.info.conversation_process_time").alias("CONVERSATION_PROCESS_TIME").cast(StringType()),
        col("cii_output.info.agent_talk_time_in_sec").alias("AGENT_TALK_TIME_IN_SEC").cast(DoubleType()),
        col("cii_output.info.customer_talk_time_in_sec").alias("CUSTOMER_TALK_TIME_IN_SEC").cast(DoubleType()),
        col("cii_output.info.source_metadata.AUDIO_START_TIME").alias("AUDIO_START_TIME").cast(StringType()),
        col("cii_output.info.source_metadata.Source_db").alias("SOURCE_DB").cast(StringType()),
        col("cii_output.info.source_metadata.Sid").alias("SID").cast(LongType()),
        col("cii_output.info.source_metadata.Site_id").alias("SITE_ID").cast(LongType()),
        col("cii_output.info.source_metadata.Audio_ch_num").alias("AUDIO_CH_NUM").cast(LongType()),
        col("cii_output.info.source_metadata.Audio_module_num").alias("AUDIO_MODULE_NUM").cast(LongType()),
        col("cii_output.info.source_metadata.Audio_start_time_gmt").alias("AUDIO_START_TIME_GMT").cast(StringType()),
        col("cii_output.info.source_metadata.Transaction_id").alias("TRANSACTION_ID").cast(StringType()),
        col("cii_output.info.source_metadata.ContactID").alias("CONTACTID").cast(StringType()),
        col("cii_output.info.source_metadata.Personal_id").alias("PERSONAL_ID").cast(StringType()),
        col("cii_output.info.source_metadata.org_id").alias("ORG_ID").cast(StringType()),
        col("cii_output.info.source_metadata.Direction").alias("DIRECTION").cast(LongType()),
        col("cii_output.info.source_metadata.Local_audio_start_time").alias("LOCAL_AUDIO_START_TIME").cast(StringType()),
        col("cii_output.info.source_metadata.Local_audio_end_time").alias("LOCAL_AUDIO_END_TIME").cast(StringType()),
        col("cii_output.info.source_metadata.Wrapup_time").alias("WRAPUP_TIME").cast(StringType()),
        col("cii_output.info.source_metadata.Agent_name").alias("AGENT_NAME").cast(StringType()),
        col("cii_output.info.source_metadata.Total_hold_time").alias("TOTAL_HOLD_TIME").cast(StringType()),
        col("cii_output.info.source_metadata.Pbx_login_id").alias("PBX_LOGIN_ID").cast(StringType()),
        col("cii_output.info.source_metadata.Ani").alias("ANI").cast(StringType()),
        col("cii_output.info.source_metadata.Extension").alias("EXTENSION").cast(StringType()),
        col("cii_output.info.source_metadata.Switch_call_id").alias("SWITCH_CALL_ID").cast(StringType()),
        col("cii_output.info.source_metadata.Switch_id").alias("SWITCH_ID").cast(StringType()),
        col("cii_output.info.source_metadata.Duration_seconds").alias("DURATION_SECONDS").cast(LongType()),
        col("cii_output.info.source_metadata.Wrapup_time_in_seconds").alias("WRAPUP_TIME_IN_SECONDS").cast(StringType()),
        col("cii_output.info.source_metadata.Dnis").alias("DNIS").cast(StringType()),
        col("cii_output.info.source_metadata.Number_of_conferences").alias("NUMBER_OF_CONFERENCES").cast(StringType()),
        col("cii_output.info.source_metadata.Number_of_holds").alias("NUMBER_OF_HOLDS").cast(StringType()),
        col("cii_output.info.source_metadata.Number_of_transfers").alias("NUMBER_OF_TRANSFERS").cast(StringType()),
        col("cii_output.info.source_metadata.Percent_of_agent_call").alias("PERCENT_OF_AGENT_CALL").cast(StringType()),
        col("cii_output.info.source_metadata.Percent_of_other_call").alias("PERCENT_OF_OTHER_CALL").cast(StringType()),
        col("cii_output.info.source_metadata.Percent_of_mutual_silence").alias("PERCENT_OF_MUTUAL_SILENCE").cast(StringType()),
        col("cii_output.info.source_metadata.Num_of_agent_cross").alias("NUM_OF_AGENT_CROSS").cast(StringType()),
        col("cii_output.info.source_metadata.Num_of_other_cross").alias("NUM_OF_OTHER_CROSS").cast(StringType()),
        col("cii_output.info.source_metadata.Language_code").alias("LANGUAGE_CODE").cast(StringType()),
        col("cii_output.info.source_metadata.IsException").alias("ISEXCEPTION").cast(LongType()),
        
        coalesce(col("cii_output.info.source_metadata.CD10"), lit("")).alias("CD10").cast(StringType()),
        col("cii_output.info.source_metadata.CD6").alias("CD6").cast(StringType()),
        col("cii_output.info.source_metadata.CD48").alias("CD48").cast(StringType()),
        col("cii_output.info.source_metadata.CD93").alias("CD93").cast(StringType()),
        col("cii_output.info.source_metadata.CD8").alias("CD8").cast(StringType()),
        coalesce(col("cii_output.info.source_metadata.CD69"), lit("")).alias("CD69").cast(StringType()),
        
        col("cii_output.speech_module_output.transcript").alias("CALL_TRANSCRIPT").cast(StringType()),

        col("cii_output.overall_level.call_driver_hierarchy.summary").alias("CALL_TRANSCRIPT_SUMMARY").cast(StringType()),
        col("classified_category.category").alias("CALL_INTENT").cast(StringType()),
        col("classified_category.tier1").alias("CALL_INTENT_TIER1").cast(StringType()),
        col("classified_category.tier2").alias("CALL_INTENT_TIER2").cast(StringType()),
        col("classified_category.tier3").alias("CALL_INTENT_TIER3").cast(StringType()),
        col("classified_category.tier4").alias("CALL_INTENT_TIER4").cast(StringType()),
        col("classified_category.tier5").alias("CALL_INTENT_TIER5").cast(StringType()),
        col("classified_category.descriptive_tag1").alias("DESCRIPTIVE_TAG1").cast(StringType()),
        col("classified_category.descriptive_tag2").alias("DESCRIPTIVE_TAG2").cast(StringType()),

        col("cii_output.overall_level.call_driver_hierarchy.callback_request").alias("CALLBACK_REQUEST").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.callback_request_speaker").alias("CALLBACK_REQUESTED_BY").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.callback_explanation").alias("CALLBACK_EXPLANATION").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.call_complexity_engine_generated").alias("CALL_COMPLEXITY").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.call_complexity_explanation_engine_generated").alias("CALL_COMPLEXITY_EXPLANATION").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.call_complexity_explanation_engine_generated_decision_logic").alias("CALL_COMPLEXITY_CLASSIFICATION_LOGIC").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.customer_attrition_indicator").alias("CUSTOMER_ATTRITION_INDICATOR").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.reason_for_customer_attrition_indicator").alias("REASON_FOR_CUSTOMER_ATTRITION_INDICATOR").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.customer_sentiment_at_end_of_call").alias("CUSTOMER_SENTIMENT_AT_END_OF_CALL").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.customer_sentiment_at_end_of_call_explanation").alias("CUSTOMER_SENTIMENT_AT_END_OF_CALL_EXPLANATION").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.customer_sentiment_towards_bsc").alias("CUSTOMER_SENTIMENT_TOWARDS_BSC").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.customer_sentiment_towards_bsc_reason").alias("CUSTOMER_SENTIMENT_TOWARDS_BSC_REASON").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.customer_sub_sentiment_towards_bsc").alias("CUSTOMER_SUB_SENTIMENT_TOWARDS_BSC").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.customer_sub_sentiment_towards_bsc_reason").alias("CUSTOMER_SUB_SENTIMENT_TOWARDS_BSC_REASON").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.presence_of_customer_intent").alias("PRESENCE_OF_CALL_INTENT").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.Number_of_intents_Call_level").alias("NUMBER_OF_INTENTS").cast(IntegerType()),
        col("cii_output.overall_level.call_driver_hierarchy.tier1_combo").alias("COMBINATION_OF_ALL_TIER1_INTENTS").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.tier1_2_combo").alias("COMBINATION_OF_ALL_TIER1_TIER2_INTENTS").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.category_with_descriptive_tag_call_level").alias("CATEGORY_WITH_DESCRIPTIVE_TAG_CALL_LEVEL").cast(StringType()),
        col("cii_output.overall_level.call_driver_hierarchy.category_combo1").alias("COMBINATION_OF_ALL_INTENTS").cast(StringType()),

        lit(1).alias("IS_ACTIVE").cast(DoubleType()),

        lit("").alias("MEMBER_ID").cast(StringType()),
        lit("").alias("MEMBER_REGISTERED").cast(StringType()),
        lit("").alias("MEMBER_LAST_ONLINE").cast(StringType()),
        lit(0).alias("CALL_SATISFACTION_SCORE").cast(IntegerType()),
        lit(0).alias("MEMBER_NPS").cast(IntegerType()),
        lit("").alias("NPS_GROUP").cast(StringType()),
        lit("").alias("SURVEY_DATE").cast(StringType()),
        lit(0).alias("MEMBER_TENURE").cast(IntegerType()),
        lit("").alias("MEMBER_PLAN").cast(StringType()),
        lit("").alias("MEMBER_GEO_COUNTY").cast(StringType()),
        lit("").alias("MEMBER_AGE").cast(StringType()),
        lit("").alias("GROUP_NUM").cast(StringType()),
        lit("").alias("GROUP_NAME").cast(StringType()),
        lit("").alias("CLASS_PLAN_ID").cast(StringType()),
        lit("").alias("MEMBER_LOB").cast(StringType()),
        lit("").alias("SKILL_NAMES").cast(StringType())
    )

    return flattened_df

# COMMAND ----------

# MAGIC %md
# MAGIC Update Tenure 

# COMMAND ----------

import nzpy
import pandas as pd
import time
from pyspark.sql.functions import when, col, lit, to_date, substring

username = "SVCADBADHDCX"  
pwd = dbutils.secrets.get(scope="scope_dcx_ds", key="PWD-SVCADBADHDCX")

# Connection to Netezza ADH_SBX_CUST360 database
try:
    cust360conn = nzpy.connect(
        user=username,
        password=pwd,
        host='npsexp01.bsc.bscal.com',
        port=5480,
        database="ADH_SBX_CUST360",
        securityLevel=1,
        logLevel=0
    )
    print("Successfully connected to the Netezza database")
except Exception as e:
    print(f"Error connecting to the database: {e}")

def update_tenure_spark(flattened_df, batch_size=1000):
    start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

    # Check if 'Member_ID' column exists
    if 'MEMBER_ID' not in flattened_df.columns:
        # log_stage("update_tenure stage", start_time, "failed", "MEMBER_ID column not found in the DataFrame")
        print("MEMBER_ID column not found in the DataFrame")
        return flattened_df

    flattened_df = flattened_df.withColumn('MEMBER_ID', col('MEMBER_ID').substr(1, 9))

    # Update Tenure for 'Not Available' Member_ID
    flattened_df = flattened_df.withColumn('MEMBER_TENURE', when(col('MEMBER_ID') == 'Not Available', lit('Not Available')))
    # log_stage("update_tenure stage", start_time, "success", "Updated Tenure for 'Not Available' Member_ID")
    print("Updated MEMBER_TENURE for 'Not Available' MEMBER_ID")

    # Filter out 'Not Available' Member_ID for the query
    valid_member_ids = [row['MEMBER_ID'] for row in flattened_df.select('MEMBER_ID').distinct().collect() if row['MEMBER_ID'] != 'Not Available']

    print(f"Valid Member Ids: {valid_member_ids}")

    if not valid_member_ids:
        # log_stage("update_tenure stage", start_time, "failed", "No valid Member IDs found in the DataFrame")
        print("No valid Member Ids found in the DataFrame")
        return flattened_df

    # Process valid Member Ids in batches
    for i in range(0, len(valid_member_ids), batch_size):
        batch_member_ids = valid_member_ids[i:i + batch_size]
        batch_member_ids_str = ', '.join([f"'{member_id}'" for member_id in batch_member_ids])
        print(f"Processing batch: {batch_member_ids}")

        query = f"""
        SELECT SBSB_ID, MIN(MEME_ORIG_EFF_DT) AS DT
        FROM ADH_SBX_CUST360.ADMIN.LU_LOB_CE_MEMBER
        WHERE (CSPD_CAT = 'M') AND (MEPE_ELIG_IND = 'Y') AND (SUBSTR(SBSB_ID, 1, 9) IN ({batch_member_ids_str}))
        GROUP BY SBSB_ID
        """

        try:
            # Execute the query and load the result into a Pandas DataFrame
            result_df = pd.read_sql(query, cust360conn)
            # log_stage("update_tenure stage", start_time, "success", f"Executed SQL query successfully for batch: {batch_member_ids}")
            # print(f"Executed SQL query successfully for batch: {batch_member_ids}")
        except Exception as e:
            # log_stage("update_tenure stage", start_time, "failed", f"Error executing query for batch {batch_member_ids}: {e}")
            print(f"Error executing query for batch {batch_member_ids}: {e}")
            continue

        # Convert the result to a Spark DataFrame
        result_spark_df = spark.createDataFrame(result_df)
        print("Result Spark DataFrame:")
        # display(result_spark_df)

        # Join the original Spark DataFrame with the result Spark DataFrame
        flattened_df = flattened_df.join(result_spark_df, flattened_df.MEMBER_ID.substr(1, 9) == result_spark_df.SBSB_ID.substr(1, 9), how='left')

        # Update the Tenure column
        flattened_df = flattened_df.withColumn('MEMBER_TENURE', when(col('DT').isNotNull(), to_date(col('DT'))).otherwise(col('MEMBER_TENURE')))

        # Drop the extra columns from the join
        flattened_df = flattened_df.drop('SBSB_ID', 'DT')

    # log_stage("update_tenure stage", start_time, "Success", "Completed update_tenure_spark function")
    print("Completed update_tenure_spark function")
    return flattened_df

# COMMAND ----------

# MAGIC %md
# MAGIC Checking fields is null

# COMMAND ----------

from pyspark.sql.functions import col, when
from pyspark.sql import DataFrame

def update_columns_if_any_nulls(df: DataFrame) -> DataFrame:
    try:
        # Check if 'Member_Registered', 'Geo_County', and 'Member_ID' columns exist
        if 'MEMBER_REGISTERED' not in df.columns or 'MEMBER_GEO_COUNTY' not in df.columns or 'MEMBER_ID' not in df.columns:
            print("DataFrame must contain columns 'MEMBER_REGISTERED', 'MEMBER_GEO_COUNTY', and 'MEMBER_ID'")
            return df
       
        # Update 'Member_ID' with 'cd_value' if the first 9 digits match
        df = df.withColumn('MEMBER_ID', 
                           when(substring(col('cd_value'), 1, 9) == substring(col('MEMBER_ID'), 1, 9), col('cd_value'))
                           .otherwise(col('MEMBER_ID')))
        
        # Update 'Member_Age' column and cast to double
        df = df.withColumn('MEMBER_ID', 
                           when(col('MEMBER_ID').isNull() | 
                                (col('MEMBER_ID') == '') | 
                                (col('MEMBER_ID') == 'None') |
                                (col('MEMBER_ID') == ' '), 'Not Available')
                           .otherwise(col('MEMBER_ID')))
        
        # Update 'Member_Registered' column
        df = df.withColumn('MEMBER_REGISTERED', 
                           when(col('MEMBER_ID') == 'Not Available', 'Not Available')
                           .when((col('MEMBER_ID') != 'Not Available') & (col('MEMBER_REGISTERED') != 'Yes'), 'No')
                           .otherwise(col('MEMBER_REGISTERED')))
        
        
        # Update 'Geo_County' column
        df = df.withColumn('MEMBER_GEO_COUNTY', 
                           when(col('MEMBER_GEO_COUNTY').isNull() | 
                                (col('MEMBER_GEO_COUNTY') == '') | 
                                (col('MEMBER_GEO_COUNTY') == ' '), 'Not Available')
                           .otherwise(col('MEMBER_GEO_COUNTY')))
        
        # Update 'State' column
        df = df.withColumn('MEMBER_STATE', 
                           when(col('MEMBER_STATE').isNull() | 
                                (col('MEMBER_STATE') == '') | 
                                (col('MEMBER_STATE') == ' '), 'Not Available')
                           .otherwise(col('MEMBER_STATE')))
        
        # Update 'Member_Age' column and cast to double
        df = df.withColumn('MEMBER_AGE', 
                           when(col('MEMBER_AGE').isNull() | 
                                (col('MEMBER_AGE') == '') | 
                                (col('MEMBER_AGE') == ' '), 'Not Available')
                           .otherwise(col('MEMBER_AGE')))
        
        # Update 'Member_Age' column and cast to double
        df=df.withColumn('MEMBER_AGE', col('MEMBER_AGE').cast('string'))

        # Update 'Member_Age' column and cast to double
        df=df.withColumn('NUMBER_OF_INTENTS', col('NUMBER_OF_INTENTS').cast('bigint'))
        
        # Update 'Tenure' column
        df = df.withColumn('MEMBER_TENURE', 
                           when(col('MEMBER_TENURE').isNull() | 
                                (col('MEMBER_TENURE') == '') | 
                                (col('MEMBER_TENURE') == ' '), 'Not Available')
                           .otherwise(col('MEMBER_TENURE')))
        
        # Update 'Plan' column
        df = df.withColumn('MEMBER_PLAN', 
                           when(col('MEMBER_PLAN').isNull() | 
                                (col('MEMBER_PLAN') == '') | 
                                (col('MEMBER_PLAN') == ' '), 'Not Available')
                           .otherwise(col('MEMBER_PLAN')))
        
        # Update 'LOB2' column
        df = df.withColumn('MEMBER_LOB', 
                           when(col('MEMBER_LOB').isNull() | 
                                (col('MEMBER_LOB') == '') | 
                                (col('MEMBER_LOB') == ' '), 'Not Available')
                           .otherwise(col('MEMBER_LOB')))
        
        # Update 'Skill_Names' column
        df = df.withColumn('SKILL_NAMES', 
                           when(col('SKILL_NAMES').isNull() | 
                                (col('SKILL_NAMES') == '') | 
                                (col('SKILL_NAMES') == ' '), 'Not Available')
                           .otherwise(col('SKILL_NAMES')))
        
        # Update 'Group_Num' column
        df = df.withColumn('GROUP_NUM', 
                           when(col('GROUP_NUM').isNull() | 
                                (col('GROUP_NUM') == '') | 
                                (col('GROUP_NUM') == ' '), 'Not Available')
                           .otherwise(col('GROUP_NUM')))
        
        # Update 'Group_Name' column
        df = df.withColumn('GROUP_NAME', 
                           when(col('GROUP_NAME').isNull() | 
                                (col('GROUP_NAME') == '') | 
                                (col('GROUP_NAME') == ' '), 'Not Available')
                           .otherwise(col('GROUP_NAME')))
        
        # Update 'Group_Name' column
        df = df.withColumn('PLAN_METAL', 
                           when(col('PLAN_METAL').isNull() | 
                                (col('PLAN_METAL') == '') | 
                                (col('PLAN_METAL') == ' '), 'Not Available')
                           .otherwise(col('PLAN_METAL')))
        
         # Update 'NPS_GROUP' column
        df = df.withColumn('NPS_GROUP', 
                           when(col('NPS_GROUP').isNull() | 
                                (col('NPS_GROUP') == '') | 
                                (col('NPS_GROUP') == ' '), 'Not Available')
                           .otherwise(col('NPS_GROUP')))
        
        
        # Update 'is_Active for LOB2' column
        df = df.withColumn('IS_ACTIVE', 
                           when(~col('MEMBER_LOB').isin(['Core Flex/ERC', 'Core Fully Insured', 'Core Self-funded', 'Premier Flex/ERC', 'Premier Fully Insured', 'Premier Self-funded','Not Available']), 0)
                           .otherwise(col('IS_ACTIVE')))
        
        #DROP THE COLUMN cd_value
        df = df.drop('cd_value')
        
        return df
    except Exception as e:
        print(f"Error in update_columns_if_any_nulls: {e}")
        return df

# COMMAND ----------

# MAGIC %md
# MAGIC Update Skill_Names from reference file

# COMMAND ----------

import pandas as pd
from pyspark.sql.functions import col, when, lit, concat, first
from pyspark.sql import DataFrame

def update_skill_names_from_verint(df: DataFrame, verint_excel_path: str) -> DataFrame:
    try:
        # Check if 'Skill_Names' and 'CD10' columns exist
        if 'SKILL_NAMES' not in df.columns or 'CD10' not in df.columns:
            print("DataFrame must contain 'SKILL_NAMES' and 'CD10' columns")
            return df
        
        # Read the Verint Excel file into Pandas DataFrames
        excel_sheets = pd.read_excel(verint_excel_path, sheet_name=None)
        
        # Check if required sheets exist
        if 'CorePremier_BSC' not in excel_sheets or 'IFP-HuntGroup' not in excel_sheets:
            print("Excel file must contain 'CorePremier_BSC' and 'IFP-HuntGroup' sheets")
            return df
        
        # Process CorePremier_BSC sheet
        corepremier_df = excel_sheets['CorePremier_BSC']
        if 'Skill' not in corepremier_df.columns or 'Skill_Name' not in corepremier_df.columns:
            print("CorePremier_BSC sheet must contain 'Skill' and 'Skill_Name' columns")
            return df
        
        corepremier_df = corepremier_df[['Skill', 'Skill_Name']]
        corepremier_spark_df = spark.createDataFrame(corepremier_df)
        corepremier_spark_df = corepremier_spark_df.withColumn('Skill_106', concat(lit('106'), col('Skill').cast('int').cast('string')))
        corepremier_spark_df = corepremier_spark_df.groupBy('Skill_106').agg(first('Skill_Name').alias('Skill_Name'))
        
        # Process IFP-HuntGroup sheet
        ifp_huntgroup_df = excel_sheets['IFP-HuntGroup']
        if 'HuntGroup' not in ifp_huntgroup_df.columns or 'Name' not in ifp_huntgroup_df.columns:
            print("IFP-HuntGroup sheet must contain 'HuntGroup' and 'Name' columns")
            return df
        
        ifp_huntgroup_df = ifp_huntgroup_df[['HuntGroup', 'Name']]
        ifp_huntgroup_spark_df = spark.createDataFrame(ifp_huntgroup_df)
        ifp_huntgroup_spark_df = ifp_huntgroup_spark_df.withColumnRenamed('HuntGroup', 'CD10_skill').withColumnRenamed('Name', 'Skill_Name')
        
        # Combine both DataFrames
        combined_spark_df = corepremier_spark_df.withColumnRenamed('Skill_106', 'CD10_skill').unionByName(ifp_huntgroup_spark_df, allowMissingColumns=True)
        
        # Join the updated DataFrame with the combined DataFrame on 'CD10'
        updated_df = df.join(combined_spark_df, df['CD10'] == combined_spark_df['CD10_skill'], how='left')
        
        # Update the 'Skill_Names' column based on the Verint match
        updated_df = updated_df.withColumn('SKILL_NAMES', 
                                           when(col('Skill_Name').isNotNull(), col('Skill_Name'))
                                           .otherwise(col('SKILL_NAMES')))
        
        # If 'Skill_Names' is still null, set it to 'Not Available'
        updated_df = updated_df.withColumn('SKILL_NAMES', 
                                           when(col('SKILL_NAMES').isNull(), lit('Not Available'))
                                           .otherwise(col('SKILL_NAMES')))
        
        # Drop the additional columns 'Skill', 'Skill_Name', and 'Skill_106'
        updated_df = updated_df.drop('Skill', 'Skill_Name', 'Skill_106', 'CD10_skill')
        
        return updated_df
    except Exception as e:
        print(f"Error in update_skill_names_from_verint: {e}")
        return df