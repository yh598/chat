# Databricks notebook source
import os
from core.llm_clients import OpenAIClient
from core.text_analytics.insights_generator import InsightsGroup, IntermediateInsightHandler, Groups, Policy
from core.text_analytics.insights_generator import create_custom_insights_module, get_insight_response 
from generic_pipeline import custom_insights, Sentiment
from generic_pipeline.custom_utils import SFUtils
from generic_pipeline import ontology_classification
import json
import time
import pandas as pd
from generic_pipeline.call_complexity import get_call_complexity


def process_transcript(transcript_path):
    global log_file_path, archive_path, op_file_path, model_gpt_4o_mini, model_gpt_4o, base_url, openai_databricks_token, ontology_sheet_path, ontology_sheet_name, simple_intent_list_path

    os.environ['model_gpt_4o_mini'] = model_gpt_4o_mini
    os.environ['model_gpt_4o'] = model_gpt_4o
    os.environ['base_url'] = base_url
    os.environ['openai_databricks_token'] = openai_databricks_token
    os.environ['ontology_sheet_path'] = ontology_sheet_path
    os.environ['ontology_sheet_name'] = ontology_sheet_name
    os.environ['simple_intent_list_path']=simple_intent_list_path
    

    llm_client = OpenAIClient(api_url = os.environ['base_url'], model_name = os.environ['model_gpt_4o_mini'], bearer_token = os.environ['openai_databricks_token'], api_key="", token_auth=True,analytics=False)


    def get_attrition_indicator_group(transcript, transcript_id):
        insight_modules = list()
        # Attrition Indicator Insight
        additional_insights = create_custom_insights_module(module_name="additional_insights", prompt_function=custom_insights._get_attrition_prompt, parsing_method=custom_insights.parse_attrition_output)
        insight_modules.append(additional_insights)

        # Evaluate attition indicator 
        evaluate_attition_module = IntermediateInsightHandler(module_name="evaluate_attrition_indicator", intermediate_call_function = custom_insights.intermediate_attrition_evaluation_func)
        insight_modules.append(evaluate_attition_module)

        # check if the customer was already termed.
        evaluate_attition_module2 = IntermediateInsightHandler(module_name="evaluate_attrition_indicator2", intermediate_call_function = custom_insights.intermediate_attrition_evaluation_func2)
        insight_modules.append(evaluate_attition_module2)

        modules_execution_order = ["additional_insights", "evaluate_attrition_indicator", "evaluate_attrition_indicator2"]
        poilcy = Policy(modules_execution_order=modules_execution_order)  
        
        insights_group = InsightsGroup(group_name="Additional Insights", transcript_id=transcript_id, transcript=transcript, llm_client=llm_client)
        insights_group.register_modules(modules=insight_modules, policy=poilcy)        
        return insights_group


    def get_sentiment_insights_group(transcript, transcript_id):
        insight_modules = list()

        # Sentiment Prompt
        sentiment_insight_bsc = create_custom_insights_module(module_name="sentiment_bsc", prompt_function=Sentiment._get_sentiment_bsc_prompt, parsing_method=Sentiment.parse_customer_sentiment_towards_bsc)
        insight_modules.append(sentiment_insight_bsc)
        # Sub Sentiment Classification
        sub_sentiment_classification_module = IntermediateInsightHandler(module_name="sub_sentiment_classification", intermediate_call_function = Sentiment.intermediate_sub_sentiment_classification_func)
        insight_modules.append(sub_sentiment_classification_module)

        modules_execution_order = ["sentiment_bsc", "sub_sentiment_classification"]
        poilcy = Policy(modules_execution_order=modules_execution_order)
        insights_group = InsightsGroup(group_name="Sentiment Insight", transcript_id=transcript_id, transcript=transcript, llm_client=llm_client)
        insights_group.register_modules(modules=insight_modules, policy=poilcy)
        return insights_group 

    def get_callback_insights_group(transcript, transcript_id):
    
        insight_modules = list()
        # callback Prompt
        callback_insight = create_custom_insights_module(module_name="callback_request", prompt_function=custom_insights._get_callback_prompt, parsing_method=custom_insights.parse_callback_request_output)
        insight_modules.append(callback_insight)

        # Step2: Callback Summary
        callback_summary_module = IntermediateInsightHandler(module_name="callback_summary", intermediate_call_function = custom_insights.intermediate_call_back_module_func)
        insight_modules.append(callback_summary_module)

        # Step 3: Final Callback
        final_call_back_module = IntermediateInsightHandler(module_name="final_callback_request", intermediate_call_function = custom_insights.final_call_back_func)
        insight_modules.append(final_call_back_module)

        modules_execution_order = ["callback_request","callback_summary","final_callback_request"]
        
        poilcy = Policy(modules_execution_order=modules_execution_order)
        insights_group = InsightsGroup(group_name="Callback Insight", transcript_id=transcript_id, transcript=transcript, llm_client=llm_client)
        insights_group.register_modules(modules=insight_modules, policy=poilcy)
        return insights_group
    
    def get_customer_sentiment_at_end_of_call_group(transcript, transcript_id):

        ## Customer Sentiment at end of the call
        insight_modules = list()
        customer_sentiment_insight = create_custom_insights_module(module_name="customer_sentiment_at_end_of_call", prompt_function=custom_insights._get_customer_sentiment_at_end_of_call, parsing_method=custom_insights.customer_sentiment_at_end_of_call_parse_output)
        insight_modules.append(customer_sentiment_insight)
        modules_execution_order = ["customer_sentiment_at_end_of_call"]
        poilcy = Policy(modules_execution_order=modules_execution_order)
        insights_group = InsightsGroup(group_name="Customer Sentiment at end of Call Insight", transcript_id=transcript_id, transcript=transcript, llm_client=llm_client)
        insights_group.register_modules(modules=insight_modules, policy=poilcy)
        return insights_group
    
    try:
        st = time.time()
        #print(transcript_path)
        file_name = transcript_path.split("/")[-1]
            
        utils = SFUtils()  
        ## Read the input json
        data=utils.read_json(transcript_path)

        #print("Reading input files")
        transcript_id ,utterances ,language ,start_time ,start_date ,end_time , end_date ,agent_name, call_direction ,meta_data , input_error = utils.get_input_values(data)
        #print(meta_data)
        if input_error != "":
            final_status = {"processed":"failed","error_message" : f"Issue with input file: {str(input_error)}","op_file_path" : "","processed_date" : "","data":{}}
            utils.save_log_json(final_status, log_file_path, transcript_path)
            return (final_status)
        
        #print("Processing Started: "+transcript_id)
        transcript=utils.clean_transcript(utterances)
        

        attrition_insights_module = get_attrition_indicator_group(transcript=transcript,transcript_id=transcript_id)
        sentiment_insights_module = get_sentiment_insights_group(transcript=transcript,transcript_id=transcript_id)
        callback_insights_module = get_callback_insights_group(transcript=transcript,transcript_id=transcript_id)
        customer_sentiment_at_end_of_call_module = get_customer_sentiment_at_end_of_call_group(transcript=transcript,transcript_id=transcript_id)

        groups = Groups([attrition_insights_module, sentiment_insights_module, callback_insights_module, customer_sentiment_at_end_of_call_module])
        output, group_errors = groups.start()

        parsed_output= get_insight_response(output) 

        ontology_classification_output=ontology_classification.ontology_classification(transcript, transcript_id)
        parsed_output.append({'Ontology Classification':{'result': ontology_classification_output}})

        error_status, error=utils.error_check(parsed_output)
        for grp_er in group_errors:
            if len(grp_er)>0:
                error_status=True
                error.append("Error in group: "+grp_er)
        if error_status==False:
            total_time_taken_per_transcript = time.time() - st
            number_of_hit,total_input_token,total_output_token=utils.get_token_count(parsed_output) 
            final_json=utils.to_final_json(parsed_output,transcript,transcript_id, utterances, language, start_time, start_date, end_time, end_date, agent_name, call_direction, meta_data,total_time_taken_per_transcript,number_of_hit,total_input_token,total_output_token) 
            # Call Complexity Start
            classified_category_list=[]
            for temp_category in final_json['cii_output']['overall_level']['call_driver_hierarchy']['classified_category']:
                temp_full_category=temp_category['tier1']+"/"+temp_category['tier2']+"/"+temp_category['tier3']+"/"+temp_category['tier4']+"/"+temp_category['tier5']+"/"+temp_category['descriptive_tag1']+"/"+temp_category['descriptive_tag2']
                temp_full_category=temp_full_category.replace("///////", "/").replace("//////", "/").replace("/////", "/").replace("////", "/").replace("///", "/").replace("//", "/").strip("/").strip()
                classified_category_list.append(temp_full_category)
            
            ### Get Call Complexity
            call_complexity_output=get_call_complexity(final_json['cii_output']['speech_module_output']['transcript'],final_json['cii_output']['info']['source_metadata'],classified_category_list)

            final_json['cii_output']['overall_level']['insights_module_output'].append({'Call Complexity':{'result':call_complexity_output}})
            final_json['cii_output']['overall_level']['call_driver_hierarchy']['call_complexity_engine_generated']=call_complexity_output['call_complexity']
            final_json['cii_output']['overall_level']['call_driver_hierarchy']['call_complexity_explanation_engine_generated']=call_complexity_output['explanation']
            final_json['cii_output']['overall_level']['call_driver_hierarchy']['call_complexity_explanation_engine_generated_decision_logic']=call_complexity_output['decision_logic']
            # Call Complexity End

            check_list=['customer_attrition_indicator', 'callback_request','callback_request_speaker','customer_sentiment_towards_bsc','customer_sub_sentiment_towards_bsc','summary','call_driver_sentence','classified_category','call_complexity_engine_generated', 'customer_sentiment_at_end_of_call']
            
            missing_kpis=utils.get_missing_kpis(final_json['cii_output']['overall_level']['call_driver_hierarchy'],check_list)
            
            if len(missing_kpis)>0:
                error.append("Missing KPIs: "+str(missing_kpis))
                final_status = {"processed":"failed","error_message" : str(error),"op_file_path" : "","processed_date" : "","data":{}} 
                utils.save_log_json(final_status, log_file_path, transcript_path)
                return (final_status)

            save_json_status,e=utils.save_json(op_file_path, transcript_id, final_json, transcript_path)
            error.append(e)
            if save_json_status:
                final_status = {"processed": "success","error_message" : str(error),"op_file_path" :  op_file_path+"/"+transcript_id+".json","processed_date" : final_json['cii_output']['info']['conversation_processed_date'] + " " + final_json['cii_output']['info']['conversation_process_time'],'data':{}}
                utils.save_log_json(final_status, log_file_path, transcript_path)
                utils.move_to_archive(archive_path, transcript_path)
            else: 
                final_status = {"processed":"failed", "error_message" : str(error), "op_file_path" : "",  "processed_date": "", "data":parsed_output}
                utils.save_log_json(final_status, log_file_path, transcript_path)
        else:
            final_status = {"processed":"failed",
                                "error_message" : str(error),
                                "op_file_path" : "",
                                "processed_date" : "",
                                'data':parsed_output}
            utils.save_log_json(final_status, log_file_path, transcript_path)
        return (final_status)
    except Exception as e:
        final_status = {"processed":"failed", "error_message" : str(e), "op_file_path" : "", "processed_date" : ""  , "data":{}}
        utils.save_log_json(final_status, log_file_path, transcript_path)
        return (final_status)
    