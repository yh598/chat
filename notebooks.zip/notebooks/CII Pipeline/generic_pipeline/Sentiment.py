import json
import re
import copy
from generic_pipeline.custom_utils import SFUtils, get_limited_input_text
from core.text_analytics.insights_generator import create_custom_insights_module, create_custom_insights_response
from core.text_analytics.insights_generator import get_insight_response
from generic_pipeline.insights_prompt import sub_sentiment_towards_bsc_positive_system_prompt, sub_sentiment_towards_bsc_positive_user_prompt, sub_sentiment_towards_bsc_negative_system_prompt, sub_sentiment_towards_bsc_negative_user_prompt, sentiment_towards_bsc_system_prompt, sentiment_towards_bsc_user_prompt
utils = SFUtils()




###### START OF SENTIMENT CLASSIFICATION ############################
    
def parse_json(input_string):
    input_string = input_string.replace("\n","")
    error = ""
    # Find the last occurrence of '{' and '}'
    start_index = input_string.rfind('{')
    end_index = input_string.rfind('}')

    extracted_json = {}
    # Ensure both '{' and '}' are found
    if start_index != -1 and end_index != -1 and start_index < end_index:
        # Extract the substring containing the last JSON object
        json_string = input_string[start_index:end_index+1]

        try:
            # Parse the JSON string
            extracted_json = json.loads(json_string)
        except Exception as e:
            try:
                import ast
                extracted_json = ast.literal_eval(json_string)
            except Exception as e:
                extracted_json = {}
                error = str(e)
    else:
        error = f"Parsing error : {input_string}"
    return extracted_json, error

def parse_customer_sub_sentiment_towards_bsc(input_string):
    final_insights = {"customer_sub_sentiment_towards_bsc": "Neutral", "customer_sub_sentiment_towards_bsc_explanation": ""}
    error = ""
    try:
        extracted_json ,error = parse_json(input_string)
        if "customer_final_sentiment_towards_bsc" in extracted_json:
            final_insights["customer_sub_sentiment_towards_bsc"] = extracted_json["customer_final_sentiment_towards_bsc"].strip()
            if "reason_for_sentiment_towards_bsc" in extracted_json:
                final_insights["customer_sub_sentiment_towards_bsc_explanation"] = extracted_json["reason_for_sentiment_towards_bsc"].strip()
        if final_insights["customer_sub_sentiment_towards_bsc"] == "frustration and anger":
            final_insights["customer_sub_sentiment_towards_bsc"] = "Anger"
        if final_insights["customer_sub_sentiment_towards_bsc"] == "frustration":
            final_insights["customer_sub_sentiment_towards_bsc"] = "Frustration"
        if final_insights["customer_sub_sentiment_towards_bsc"] == "fear":
            final_insights["customer_sub_sentiment_towards_bsc"] = "Fear"
        if final_insights["customer_sub_sentiment_towards_bsc"] == "surprise":
            final_insights["customer_sub_sentiment_towards_bsc"] = "Surprise"
        if final_insights["customer_sub_sentiment_towards_bsc"] == "joy":
            final_insights["customer_sub_sentiment_towards_bsc"] = "Joy"
        if final_insights["customer_sub_sentiment_towards_bsc"] == "gratitude & thankfulness":
            final_insights["customer_sub_sentiment_towards_bsc"] = "Gratitude & Thankfulness"
        if final_insights["customer_sub_sentiment_towards_bsc"] == "satisfied":
            final_insights["customer_sub_sentiment_towards_bsc"] = "Satisfied"
    except Exception as e:
        error = str(e)
    return final_insights, error

def _get_sentiment_prompt_bsc_p(insight_generation_module):
    system_prompt = sub_sentiment_towards_bsc_positive_system_prompt
    user_prompt = sub_sentiment_towards_bsc_positive_user_prompt.format(input_text = insight_generation_module.transcript)
    
    
    message = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
    return message



def _get_sentiment_prompt_bsc_n(insight_generation_module):
    system_prompt = sub_sentiment_towards_bsc_negative_system_prompt
    user_prompt = sub_sentiment_towards_bsc_negative_user_prompt.format(input_text = insight_generation_module.transcript)
    message = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
    return message
 
def parse_customer_sentiment_towards_bsc(input_string):
    final_insights = {"sentiment": "Neutral", "explanation": ""}
    error = ""
    try:
        extracted_json, error = parse_json(input_string)
        if "customer_overall_sentiment_towards_bsc" in extracted_json:
            final_insights["sentiment"] = extracted_json["customer_overall_sentiment_towards_bsc"]
            if "reason_for_sentiment_towards_bsc" in extracted_json:
                final_insights["explanation"] = extracted_json["reason_for_sentiment_towards_bsc"]
    except Exception as e:
        error = error(e)
    return final_insights, error

def _get_sentiment_bsc_prompt(insight_generation_module):
    system_prompt = sentiment_towards_bsc_system_prompt
    user_prompt = sentiment_towards_bsc_user_prompt.format(input_text = insight_generation_module.transcript)

    message = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
    return message

def intermediate_sub_sentiment_classification_func(insights_generation_module):
    modules_list = list()
    sentiment_output_bsc = copy.deepcopy(get_insight_response(insights_generation_module.final_insights["sentiment_bsc"]["output"]))
    bsc = sentiment_output_bsc["sentiment"]
    if bsc.lower() == "positive":
        msg_sent_bsc = _get_sentiment_prompt_bsc_p(insights_generation_module)
        module = create_custom_insights_module(module_name="sub sentiment classification", prompt_message_list=msg_sent_bsc, parsing_method=parse_customer_sub_sentiment_towards_bsc)
        modules_list.append(module) 
    elif bsc.lower() == "negative":
        msg_sent_bsc = _get_sentiment_prompt_bsc_n(insights_generation_module)
        module = create_custom_insights_module(module_name="sub sentiment classification", prompt_message_list=msg_sent_bsc, parsing_method=parse_customer_sub_sentiment_towards_bsc)
        modules_list.append(module)
    else:
        ouptut={"customer_sub_sentiment_towards_bsc": "Neutral", "customer_sub_sentiment_towards_bsc_explanation": ""}
        module = create_custom_insights_response(ouptut)
        modules_list.append(module)

    return modules_list 
   


