from collections import Counter
import json
import re
import ast
import copy
import pandas as pd
from openai import AzureOpenAI, OpenAI
import os
import time
from retry import retry
import ast
import json
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
import copy
import os
from tqdm import tqdm
import json
import pandas as pd
import concurrent.futures
from azure.identity import DefaultAzureCredential, get_bearer_token_provider
from openai import AzureOpenAI

folder_path = ""

df_dict = {"Transcript ID": [], "Reasons": [], "Reasons_With_Id": [], "Call Category": [], "Descriptive Tag1": [], "Descriptive Tag2": [], "Tier 1": [], "Tier 2": [], "Tier 3": [], "Tier 4": [], "Tier 5": [], "conversation_start_date": [], "conversation_processed_date": []}

def error_check(df):
    for index, row in df.iterrows():
        error_list = row['error_list']
        try:
            error_list = ast.literal_eval(error_list)
        except Exception as e:
            error_list = error_list
        if isinstance(error_list, str):
            if len(error_list)>0:
                print(error_list)
                return True, error_list
        elif isinstance(error_list, list): 
            for error in error_list:
                if isinstance(error, str):
                    if len(error)>0:
                        print(error)
                        return True, error_list
                elif isinstance(error, list):
                    for error_1 in error:
                        if isinstance(error_1, str):
                            if len(error_1)>0:
                                print(error_1)
                                return True, error_list
    return False, "" 

def save_log_json(data, op_path):
    try:
        with open(op_path, 'w', encoding = 'utf-8') as f:
            json.dump(data, f, ensure_ascii = False, indent = 4)
    except Exception as e:
        print(f"error saving logs {op_path}")
### LLM Client

def get_llm_client():
    client = OpenAI(
        api_key = os.environ['openai_databricks_token'],
        base_url = os.environ['base_url']
       
    )
    return client

@retry(Exception , tries=3, delay=2)
def output_from_llm(messages, deployment_id, max_tokens=None):
    try:
        client = get_llm_client()
        if max_tokens==None:
            response = client.chat.completions.create(
                model = deployment_id,
                messages = messages,
                temperature=0.0,
                seed=42
            )
        else:
            response = client.chat.completions.create(
                model = deployment_id,
                messages=messages,
                seed=42,
                temperature=0.0,
                max_tokens=max_tokens
            )
        end = time.time()
        return response
    except Exception as e:
        raise
    
def get_llm_response(messages, max_tokens=None):
    try:
        deployment_id = os.environ['model_gpt_4o']
        st = time.time()
        response = output_from_llm(messages, deployment_id, max_tokens)
        output = response.choices[0].message.content
        end = time.time()
        analytics = {"messages":messages,"raw_output":output,"llm_time_taken":end - st,"input_token_size":response.usage.prompt_tokens,"output_token_size":response.usage.completion_tokens}
        error = ""
    except Exception as e:
        output = ""
        error = str(e)
        analytics = {}
    return output, analytics, error

def read_json(path):
    with open(path) as json_file:
        data = json.load(json_file)
    return data

def get_details(file,folder_path):
    try:
        data = read_json(os.path.join(folder_path, f"""{file}"""))
        call_driver_output = data["cii_output"]["overall_level"]["call_driver_hierarchy"]
        transcript_id = data["cii_output"]["info"]["id"]
        conversation_processed_date = data["cii_output"]["info"]["conversation_processed_date"]
        conversation_start_date = data["cii_output"]["info"]["conversation_start_date"]
        for category in call_driver_output["classified_category"]:
            call_category = category["category"]
            descriptive_tag1 = category["descriptive_tag1"]
            descriptive_tag2 = category["descriptive_tag2"]
            tier1 = category["tier1"]
            tier2 = category["tier2"]
            tier3 = category["tier3"]
            df_dict["Transcript ID"].append(transcript_id)
            df_dict["Reasons"].append(category['reason'])
            df_dict["Call Category"].append(call_category)
            df_dict["Descriptive Tag1"].append(descriptive_tag1)
            df_dict["Descriptive Tag2"].append(descriptive_tag2)
            df_dict["Tier 1"].append(tier1)
            df_dict["Tier 2"].append(tier2)
            df_dict["Tier 3"].append(tier3)
            df_dict["Tier 4"].append(category["tier4"])
            df_dict["Tier 5"].append(category["tier5"])
            df_dict["Reasons_With_Id"].append(json.dumps({category['reason']: transcript_id}))
            df_dict["conversation_processed_date"].append(conversation_processed_date)
            df_dict["conversation_start_date"].append(conversation_start_date)
    except Exception as e:
        print(e)
        print(category)

def load_data_as_df(folder_path,max_workers=8):
    # Use ThreadPoolExecutor to copy files concurrently
    # check if the inside folder_path has folders
    if len(os.listdir(folder_path)) > 0:
        if "Sagility" in os.listdir(folder_path):
            temp_folder_path = os.path.join(folder_path, "Sagility")
            files_to_check = os.listdir(temp_folder_path)
            files_to_check = [file for file in files_to_check if file.endswith(".json")]
            print('Found {} files to process in Sagility'.format(len(files_to_check)))
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(get_details, file,temp_folder_path) for file in files_to_check]
                concurrent.futures.wait(futures)
        if "TTec" in os.listdir(folder_path):
            temp_folder_path = os.path.join(folder_path, "TTec")
            files_to_check = os.listdir(temp_folder_path)
            files_to_check = [file for file in files_to_check if file.endswith(".json")]
            print('Found {} files to process in TTec'.format(len(files_to_check)))
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(get_details, file,temp_folder_path) for file in files_to_check]
                concurrent.futures.wait(futures)
        if "Verint" in os.listdir(folder_path):
            temp_folder_path = os.path.join(folder_path, "Verint")
            files_to_check = os.listdir(temp_folder_path)
            files_to_check = [file for file in files_to_check if file.endswith(".json")]
            print('Found {} files to process in Verint'.format(len(files_to_check)))
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(get_details, file,temp_folder_path) for file in files_to_check]
                concurrent.futures.wait(futures)
        files_to_check = os.listdir(folder_path)
        # keep oonly the files that are ends with json
        files_to_check = [file for file in files_to_check if file.endswith(".json")]
        print('Found {} files to process '.format(len(files_to_check)))
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(get_details, file,folder_path) for file in files_to_check]
            concurrent.futures.wait(futures)
    return pd.DataFrame(df_dict)

def get_category_groups(folder_path):
    df = load_data_as_df(folder_path) 
    print('Total number of transcripts',len(df))
    unique_transcripts = len(list(df["Transcript ID"].unique()))
    unique_call_categories = list(df["Call Category"].unique())

    input_dataframe_to_process = pd.DataFrame(columns=["Sno", "name_of_top_driver", "call_category", "reasons", "reasons_with_id", "percent_of_calls", "tier1", "tier2", "tier3", "tier4", "tier5", "descriptive_tag1", "descriptive_tag2", "conversation_start_date", "conversation_processed_date"])

    for i in range(len(unique_call_categories)):
        call_category = unique_call_categories[i]
        index = i 
        filtered_df = df[df["Call Category"] == call_category].reset_index(drop=True)
        unique_filtered_df_transcripts = len(list(filtered_df["Transcript ID"].unique()))
        tier_1 = list(filtered_df["Tier 1"])[0]
        tier_2 = list(filtered_df["Tier 2"])[0]
        tier_3 = list(filtered_df["Tier 3"])[0]
        tier_4 = list(filtered_df["Tier 4"])[0]
        tier_5 = list(filtered_df["Tier 5"])[0]
        name_of_top_driver = list(filtered_df["Call Category"])[0]
        conversation_processed_date = list(filtered_df["conversation_processed_date"])[0]
        conversation_start_date = list(filtered_df["conversation_start_date"])[0]
        descriptive_tag1 = list(filtered_df["Descriptive Tag1"])[0]
        descriptive_tag2 = list(filtered_df["Descriptive Tag2"])[0]
        selected_reasons = filtered_df["Reasons"].to_list()
        selected_reasons_with_id = filtered_df["Reasons_With_Id"].to_list()

        # Append Value
        input_dataframe_to_process.loc[index] = [index + 1, name_of_top_driver, call_category, selected_reasons, selected_reasons_with_id, round((unique_filtered_df_transcripts / unique_transcripts) * 100, 2), tier_1, tier_2, tier_3, tier_4, tier_5, descriptive_tag1, descriptive_tag2, conversation_start_date, conversation_processed_date]
    
    input_dataframe_to_process["insights"] = [""] * len(input_dataframe_to_process["Sno"])
    input_dataframe_to_process["actionables"] = [""] * len(input_dataframe_to_process["Sno"])
    input_dataframe_to_process["error_list"] = [""] * len(input_dataframe_to_process["Sno"])

    sorted_df = input_dataframe_to_process.sort_values(by="percent_of_calls", ascending=False)
    sorted_df.reset_index(drop=True, inplace=True)
    sorted_df["Sno"] = list(range(1, len(sorted_df) + 1))  
    return sorted_df

def get_groups(reasons, category):
    reasons = "\n".join(reasons)
    system_prompt = """List down optimal number of topics for the provided Reasons."""
    user_prompt = f"""```Topics```: {reasons}

Generate `Issue Topics` only based on the causing issues under this hierarchy `{category}` and these topics should provide the distribution of all the issues amoung the ```Topics``` with in a small buckets of `Issue Topics`. Basically avoid long tails of topics. 
Keep `Issue Topics` a standard, comprehensible short single phrase that highlights a unique issue amoung the `Topics` Provided. Ensure all the issues are covered in maximum of 35 Topics.

Mandatorily Provide json response:
    Key name should be 'Issue Topics' and value should be list of topics.
```Json"""
    
    messages = [{'role': 'system', "content": system_prompt}, {"role": "user", "content": user_prompt}]
    try:
        response , analytics, error = get_llm_response(messages)
        start = "{"
        end = "}"
        response = response[response.find(start): response.rfind(end) + len(end)]
        response = ast.literal_eval(response)
        return response,analytics, error
    except Exception as e:
        error=str(e)
        analytics = {}
        print(e)
    return {},analytics, error

    
def get_classification(topics, reason, category):
    try:
        system_prompt = """You are a expert in classifying issues related to '{category}'."""
        user_prompt = f"""
Classify the Issue ```{reason}``` into one of the 
`Topics`:
```{topics}```
Do not create any new Topics, Topic should mandatorily be one of the same `Topics` provided which is matching the `Issue`. Provide xml response, use <classified_topic> as the tag name.
Issue: ```{reason}```
"""
        messages = [{'role': 'system', "content": system_prompt}, {'role': 'user', 'content': user_prompt}]
        llm_response,analytics, error = get_llm_response(messages)
        return llm_response, reason, analytics, error
    except Exception as e:
        print(e)
        error = str(e)
        analytics = {}
        return "", reason,analytics, error
    
def standardize(reasons, intent_name,max_workers, groups=None):
    analytics_list = []
    error_list = []
    tmp_reasons = reasons
    intent = intent_name
    total_reasons_count = len(reasons)
    if groups == None:
        groups = dict()
        groups["failed"] = list()
        groups["Miscellaneous"] = list()
    topics,analytics, error = get_groups(tmp_reasons, intent_name)
    analytics_list.append(analytics)
    error_list.append(error)
    try:
        topics = topics["Issue Topics"]
    except:
        topics,analytics, error = get_groups(tmp_reasons, intent_name)
        analytics_list.append(analytics)
        error_list.append(error)
        topics = topics["Issue Topics"]
        
    topic_names = topics
    topics_len = len(topics)
    topics = ",\n".join(topics)
    # print(f"Generated Topics: {topics}")
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = list()
        for reason in reasons:
            futures.append(executor.submit(get_classification, *[topics, reason, intent_name]))
        for future in as_completed(futures):
            result, reason ,analytics, error = future.result()
            analytics_list.append(analytics)
            error_list.append(error)
            start = "<classified_topic>"
            end = "</classified_topic>"
            if start in result and end in result:
                classified_topic = result[result.find(start) + len(start): result.find(end)]
                if len(classified_topic.strip()) > 0 and classified_topic in topic_names:
                    if classified_topic not in groups:
                        groups[classified_topic] = list()
                    groups[classified_topic].append(reason)
                else:
                    groups["Miscellaneous"].append(reason)
            else:
                groups["failed"].append(reason)
    return groups, analytics_list, error_list
        

def reason_standardization(folder_path,op_log_file_name,max_workers=5):
    from tqdm import tqdm
    import pandas as pd
    final_df = get_category_groups(folder_path) 
    print("Total Rows: ", len(final_df))
    temp_json_save=[]
    for id, row in final_df.iterrows():
        try:
            category = row["name_of_top_driver"]
            # if category != "Customer/Plan inquiry/Enrollment/Special Enrollment Period Assistance":
            #     continue
            reasons_with_ids = row["reasons_with_id"]
            reasons = [list(json.loads(i).keys())[0] for i in reasons_with_ids]
            total = len(reasons)
            print(category ,"reasons:",total)
            groups, analytics_list, error_list = standardize(reasons, category.replace("Customer/","").replace("Self/","").strip("/").strip(),max_workers) 
            op = list()
            final_reasons = list()
            
            for k, v in groups.items():
                no_of_items = len(v)
                k = k.strip().strip("\n").strip("\t").strip()
                final_reasons.append({k: len(v)})
                for item in v:
                    if len(item.strip()) != 0:
                        for reasons_with_id in reasons_with_ids:
                            reasons_with_id=json.loads(reasons_with_id)
                            if list(reasons_with_id.keys())[0] == item:
                                tmp = dict()
                                tmp["old_reason"] = item
                                tmp["new_reason"] = k
                                tmp["transcript_id"] = list(reasons_with_id.values())[0]
                                tmp["category"] = category
                                op.append(tmp)
            final_reasons.sort(key=lambda x: list(x.values())[0], reverse=True)
            final_reasons1= "\n".join([f"{list(i.keys())[0]} {round((list(i.values())[0]/total) * 100, 2)}%" for i in final_reasons])
            final_df.loc[id, "insights"] = final_reasons1
            final_df.loc[id, "error_list"] = json.dumps(error_list)
            final_df.loc[id, "analytics"] = json.dumps(analytics_list) 
            temp_json_save.append({"category": category, "reasons": reasons, "groups": json.dumps(groups) , "final_reasons": json.dumps(final_reasons), "final_reasons1": final_reasons1, "reason_mappig": json.dumps(op), "analytics": json.dumps(analytics_list), "error_list": error_list})
            save_log_json(temp_json_save, op_log_file_name)     
                                        
        except Exception as e:
            print(e)
    return final_df
