import ast, json
import re
import copy
from generic_pipeline.custom_utils import SFUtils
from core.text_analytics.insights_generator import create_custom_insights_module, create_custom_insights_response
from core.text_analytics.insights_generator import get_insight_response
from generic_pipeline.insights_prompt import attrition_indicator_system_prompt, attrition_indicator_user_prompt, callback_system_prompt1, callback_user_prompt1, callback_summarizer_system_prompt, callback_summarizer_user_prompt, callback_final_system_prompt, callback_final_user_prompt, customer_sentiment_at_end_of_call_system_prompt, customer_sentiment_at_end_of_call_user_prompt,attrition_evaluation_system_prompt,attrition_evaluation_user_prompt, attrition_evaluation_system_prompt2,attrition_evaluation_user_prompt2

utils = SFUtils()
from textwrap import dedent

def parse_json(input_string):
    input_string = input_string.replace("\n","")
    # Find the last occurrence of '{' and '}'
    start_index = input_string.rfind('{')
    end_index = input_string.rfind('}')

    extracted_json = {}
    # Ensure both '{' and '}' are found
    if start_index != -1 and end_index != -1 and start_index < end_index:
        # Extract the substring containing the last JSON object
        json_string = input_string[start_index:end_index+1]

        try:
            # Parse the JSON string
            extracted_json = json.loads(json_string)
            return extracted_json, ""
        except Exception as e:
            try:
                import ast
                extracted_json = ast.literal_eval(json_string)
                return extracted_json, ""
            except Exception as e:
                extracted_json = {}
                error = str(e)
                return {}, error





### Call Back Request ####
def parse_callback_request_output(input_string):
    data = {"callback_request": "No", "callback_request_speaker": "NA",  "explanation": ""}
    error = ""
    try:
        customer_requested_callback = "No"
        agent_suggested_callback = "No"
        is_customer_requested_callback_derived = "No"
        is_agent_suggested_callback_derived = "No"

        if not (input_string == None or input_string == ""):
            pattern = r"<customer_requested_callback>:\s*(.*?)\s*<agent_suggested_callback>:\s*(.*?)\s*<is_customer_requested_callback_derived>:\s*(.*?)\s*<is_agent_suggested_callback_derived>:\s*(.*?)\s*"

            pattern1 = r"<customer_requested_callback>(.*?)</customer_requested_callback>\s*<agent_suggested_callback>(.*?)</agent_suggested_callback>\s*<is_customer_requested_callback_derived>(.*?)</is_customer_requested_callback_derived>\s*<is_agent_suggested_callback_derived>(.*?)</is_agent_suggested_callback_derived>"

            match = re.search(pattern, input_string, re.DOTALL)

            match1 = re.search(pattern1, input_string, re.DOTALL)

            if match:
                customer_requested_callback = match.group(1)
                agent_suggested_callback = match.group(2)
                is_customer_requested_callback_derived = match.group(3)
                is_agent_suggested_callback_derived = match.group(4)
            elif match1:
                customer_requested_callback = match1.group(1)
                agent_suggested_callback = match1.group(2)
                is_customer_requested_callback_derived = match1.group(3)
                is_agent_suggested_callback_derived = match1.group(4)

        if customer_requested_callback == "Yes":
            data["callback_request"] = "Yes"
            data["callback_request_speaker"] = "Customer"
            if is_customer_requested_callback_derived == "Yes":
                data["callback_request"] = "No"
                data["callback_request_speaker"] = "NA"
        if agent_suggested_callback == "Yes":
            data["callback_request"] = "Yes"
            data["callback_request_speaker"] = "Agent"
            if is_agent_suggested_callback_derived == "Yes":
                data["callback_request"] = "No"
                data["callback_request_speaker"] = "NA"
    except Exception as e:
        error = str(e)
  
    final_insights = {}
    final_insights["additional_insights"] = {}
    final_insights["additional_insights"]["callback_request"] = data["callback_request"]
    final_insights["additional_insights"]["callback_request_speaker"] = data["callback_request_speaker"]
    final_insights["additional_insights"]["callback_request_explanation"] = data["explanation"]
    return final_insights, error


def _get_callback_prompt(insight_generation_module):
    
    transcript = insight_generation_module.transcript.replace("\n\n", "\n").lower().replace("customer:", "Customer:").replace("agent:","Agent:").replace("call back number", "")
    
    system_prompt = callback_system_prompt1
    user_prompt = callback_user_prompt1.format(input_text = transcript)
    message = [{"role": "system", "content": system_prompt},               
               {"role":"user","content": user_prompt}]
    return message

def callback_summarize_prompt(transcript):
    transcript= transcript.replace("\n\n", "\n").lower().replace("customer:", "Customer:").replace("agent:","Agent:").replace("call back number", "").replace("callback phone number", "").replace("callback number", "").replace("callback phone number", "")

    system_prompt = callback_summarizer_system_prompt
    user_prompt = callback_summarizer_user_prompt.format(input_text = transcript)
    message = [{"role": "system", "content": system_prompt},               
               {"role":"user","content": user_prompt}]
    return message

def parse_callback_summarize_output(input_string,metadata):
    temp= { "callback_summary": "", "flag": "No"}
    error = ""
    try:
        if input_string is None:
            input_string = ""
        temp= { "callback_summary": input_string, "flag": "Yes"}
    except Exception as e:
        error = str(e)
    return temp,error

def intermediate_call_back_module_func(insights_generation_module): 
    modules_list = list()
    callback_response=get_insight_response(insights_generation_module.final_insights["callback_request"]["output"])
    callback=callback_response['additional_insights']['callback_request'] 
    if callback is not None and callback == "Yes":
        callback_prompt_message_list =callback_summarize_prompt(insights_generation_module.transcript)
        module = create_custom_insights_module(module_name="callback_summary", prompt_message_list=callback_prompt_message_list, parsing_method=parse_callback_summarize_output, metadata={})
        modules_list.append(module)
    else:
        module = create_custom_insights_response({"callback_summary": "", "flag": "No"})
        modules_list.append(module)
    return modules_list 

def final_callback_prompt(transcript):
    system_prompt = callback_final_system_prompt
    user_prompt = callback_final_user_prompt.format(input_text = transcript)
    message = [{"role": "system", "content": system_prompt},{"role":"user","content": user_prompt}]
    return message

def final_callback_parse_output(input_string,metadata):
    callback_request = ""
    explanation = ""
    speaker = ""
    error = ""
    try:
        customer_requested_callback=""
        customer_requested_callback_explanation=""
        agent_suggested_callback=""
        agent_suggested_callback_explanation=""
        explanation=""
        callback_request="No"
        speaker="NA"

        customer_requested_callback_pattern = r"<answer1>(.*?)</answer1>"
        customer_requested_callback_explanation_pattern = r"<explain1>(.*?)</explain1>"
        customer_requested_callback_match = re.search(customer_requested_callback_pattern, input_string)
        customer_requested_callback_explanation_match = re.search(customer_requested_callback_explanation_pattern, input_string)

        agent_suggested_callback_pattern = r"<answer2>(.*?)</answer2>"
        agent_suggested_callback_explanation_pattern=r"<explain2>(.*?)</explain2>"
        agent_suggested_callback_match = re.search(agent_suggested_callback_pattern, input_string)
        agent_suggested_callback_explanation_match = re.search(agent_suggested_callback_explanation_pattern, input_string)

        if agent_suggested_callback_match:
            agent_suggested_callback = agent_suggested_callback_match.group(1)
            if agent_suggested_callback_explanation_match:
                agent_suggested_callback_explanation = agent_suggested_callback_explanation_match.group(1)
        if customer_requested_callback_match:
            customer_requested_callback = customer_requested_callback_match.group(1)
            if customer_requested_callback_explanation_match:
                customer_requested_callback_explanation = customer_requested_callback_explanation_match.group(1)
        
        if customer_requested_callback=="Yes":
            speaker="Customer"
        if agent_suggested_callback=="Yes":  
            speaker="Agent"

        if customer_requested_callback=="Yes" or agent_suggested_callback=="Yes":
            explanation = customer_requested_callback_explanation + " " + agent_suggested_callback_explanation
            callback_request="Yes"
        else:
            explanation=""
            callback_request="No"

        if "indicate" in agent_suggested_callback_explanation or 'indicate' in customer_requested_callback_explanation or "implies" in agent_suggested_callback_explanation or 'implies' in customer_requested_callback_explanation or "possibility" in agent_suggested_callback_explanation or 'possibility' in customer_requested_callback_explanation or "voice message" in agent_suggested_callback_explanation or 'voice message' in customer_requested_callback_explanation:
            explanation=""
            callback_request="No"
            speaker="NA"
    except Exception as e:
        error = str(e)
    final_insights = {}
    final_insights["additional_insights"] = {}
    final_insights["additional_insights"]["callback_request"] = callback_request
    final_insights["additional_insights"]["callback_request_speaker"] =  speaker
    final_insights["additional_insights"]["callback_request_explanation"] =  explanation 
    return final_insights,error

def final_call_back_func(insights_generation_module): 
    modules_list=list() 
    callback_summary_response=get_insight_response(insights_generation_module.final_insights["callback_summary"]["output"])
    if isinstance(callback_summary_response, list):
        if len(callback_summary_response) > 0:
            callback_summary_response=callback_summary_response[0]
        else:
            callback_summary_response={"flag": "No", "callback_summary": ""}
    flag= callback_summary_response["flag"]
    if flag == "Yes":
        callback_summary = callback_summary_response["callback_summary"]
        callback_prompt_message_list=final_callback_prompt(callback_summary)
        module = create_custom_insights_module(module_name="final_callback_request", prompt_message_list=callback_prompt_message_list, parsing_method=final_callback_parse_output, metadata={})
        modules_list.append(module)
    else:
        module = create_custom_insights_response({"additional_insights": { "callback_request": "No", "callback_request_speaker": "NA", "callback_request_explanation": ""}})
        modules_list.append(module)
    return modules_list 


### END of Call back KPI ###


### Customer Sentiment at end of the call ###

def customer_sentiment_at_end_of_call_parse_output(input_string):
    sentiment_pattern = r"<final_customer_sentiment>(.*?)</final_customer_sentiment>"
    explanation_pattern  = r"<final_customer_sentiment_explanation>(.*?)</final_customer_sentiment_explanation>"
    error = ""

    sentiment_match = re.search(sentiment_pattern, input_string)
    explan_match = re.search(explanation_pattern, input_string)

    try:
        if sentiment_match:
            final_customer_sentiment = sentiment_match.group(1)
            if explan_match:
                final_customer_sentiment_explanation = explan_match.group(1)
            else:
                final_customer_sentiment_explanation = ""
        else:
            final_customer_sentiment = "Neutral"
            final_customer_sentiment_explanation = ""
            error = "Parsing issue"
    except Exception as e:
        error = str(e)
        final_customer_sentiment = "Neutral"
        final_customer_sentiment_explanation = ""
    output = {"final_customer_sentiment": final_customer_sentiment.strip(), "final_customer_sentiment_explanation": final_customer_sentiment_explanation.strip()}
    return output, error
    
def _get_customer_sentiment_at_end_of_call(insight_generation_module):
    system_prompt = customer_sentiment_at_end_of_call_system_prompt

    user_prompt = customer_sentiment_at_end_of_call_user_prompt.format(input_text = insight_generation_module.transcript.replace("\n\n", "\n").lower().replace("customer:", "Customer:").replace("agent:","Agent:"))

    message = [{"role": "system", "content": system_prompt},               
               {"role":"user","content": user_prompt}]
    return message

### End of Customer Sentiment at end of Call ###

#### Attrition KPI ####

def parse_attrition_output(output):
    final_insights = {"additional_insights":{"customer": {"customer_attrition_check": "No", "reason_for_customer_attrition": ""}}}
    try:
        parsed_output, parse_error = parse_json(output)

        final_output_json = {"customer_attrition_check": "", "reason_for_attrition": ""}
        'customer_attrition_check','reason_for_customer_attrition'
        if 'customer_attrition_check' in parsed_output:
            final_output_json['customer_attrition_check'] = parsed_output['customer_attrition_check']
        if 'reason_for_customer_attrition' in parsed_output:
            final_output_json['reason_for_customer_attrition'] = parsed_output['reason_for_customer_attrition']

        final_insights["additional_insights"]["customer"]['customer_attrition_check'] = final_output_json['customer_attrition_check']
        final_insights["additional_insights"]["customer"]['reason_for_customer_attrition'] = final_output_json['reason_for_customer_attrition']
        return final_insights, ""
    except Exception as e:
        return final_insights, str(e)
     
### Prompts Methods and Parsing methods for Attrition ###
def _get_attrition_prompt(insight_generation_module): 

    system_prompt = attrition_indicator_system_prompt
    user_prompt = attrition_indicator_user_prompt.format(transcript = insight_generation_module.transcript)
    message = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}] 
    return message

def attrition_evaluation_parse_output(input_string,metadata):
    output={"customer_attrition_check": "No", "customer_attrition_check_explanation": ""}
    error = ""
    try:
        if input_string and input_string.lower().startswith("yes"):
            output["customer_attrition_check"] = "Yes"
            output["customer_attrition_check_explanation"] = input_string
        else:
            output["customer_attrition_check"] = "No"
            output["customer_attrition_check_explanation"] = input_string
    except Exception as e:
        error = str(e)
    return output, error

def attrition_evaluation_prompt(transcript):
    system_prompt=attrition_evaluation_system_prompt
    attrition_prompt=attrition_evaluation_user_prompt
    user_prompt = attrition_prompt
    user_prompt = user_prompt.format(
            transcript = transcript.lower().strip())
    message = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}] 
    return message

def attrition_evaluation_parse_output2(input_string,metadata):
    #print("attrition output", metadata)
    output={"customer_attrition_check": "No", "customer_attrition_check_explanation": ""}
    error = ""
    try:
        if input_string and input_string.lower().startswith("yes"):
            output["customer_attrition_check"] = "No"
            output["customer_attrition_check_explanation"] = "Plan / Policy already cancelled"
        else:
            output["customer_attrition_check"] = "Yes"
            output["customer_attrition_check_explanation"] = ""
    except Exception as e:
        error = str(e)
    return output, error

def attrition_evaluation_prompt2(transcript):
    ## to check if plan was already cancelled
    system_prompt = attrition_evaluation_system_prompt2
    attrition_prompt = attrition_evaluation_user_prompt2
    user_prompt = attrition_prompt
    user_prompt = user_prompt.format(
            transcript = transcript.lower().strip())
    message = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}] 
    return message

def intermediate_attrition_evaluation_func(insights_generation_module):
    modules_list=list()  
    transcript = insights_generation_module.transcript 
    attrition_indicator_output=get_insight_response(insights_generation_module.final_insights["additional_insights"]["output"])
    customer_attrition_indicator= attrition_indicator_output['additional_insights']['customer']['customer_attrition_check'].lower().replace("y", "Y").replace("n", "N")
    reason_for_customer_attrition_indicaton=attrition_indicator_output['additional_insights']['customer']['reason_for_customer_attrition']

    if customer_attrition_indicator == "Yes": 
        attrition_evaluation_prompt_list=attrition_evaluation_prompt(transcript)
        module = create_custom_insights_module(module_name="evaluate_attrition_indicator", prompt_message_list=attrition_evaluation_prompt_list, parsing_method=attrition_evaluation_parse_output, metadata={})
        modules_list.append(module)
    else:
        module = create_custom_insights_response( {"customer_attrition_check": "No", "customer_attrition_check_explanation": reason_for_customer_attrition_indicaton}) 
        modules_list.append(module)
    return modules_list

def intermediate_attrition_evaluation_func2(insights_generation_module):
    modules_list=list()  
    transcript = insights_generation_module.transcript 

    # [{'customer_attrition_check': 'No', 'customer_attrition_check_explanation': 'No, the customer did not explicitly state they want to cancel their plan.'}]
    attrition_indicator_output=get_insight_response(insights_generation_module.final_insights["evaluate_attrition_indicator"]["output"])
    print("attrition_output", attrition_indicator_output)
    customer_attrition_indicator= attrition_indicator_output[0]['customer_attrition_check'].lower().replace("y", "Y").replace("n", "N")
    reason_for_customer_attrition_indicaton=attrition_indicator_output[0]['customer_attrition_check_explanation']

    if customer_attrition_indicator == "Yes": 
        attrition_evaluation_prompt_list=attrition_evaluation_prompt2(transcript)
        module = create_custom_insights_module(module_name="evaluate_attrition_indicator2", prompt_message_list=attrition_evaluation_prompt_list, parsing_method=attrition_evaluation_parse_output2, metadata=insights_generation_module)
        modules_list.append(module)
    else:
        module = create_custom_insights_response( {"customer_attrition_check": "No", "customer_attrition_check_explanation": reason_for_customer_attrition_indicaton}) 
        modules_list.append(module)
    return modules_list


### End of Attrition KPI ###
