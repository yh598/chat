# Databricks notebook source
# !pip install azure-identity
# !pip install python-dotenv
# !pip install PyYaml
# !pip install dotmap
# !pip install pandas
# !pip install requests
# !pip install openai  
# !pip install openpyxl
# !pip install retry
# dbutils.library.restartPython()

# COMMAND ----------

# dbutils.library.restartPython()

# COMMAND ----------

# import os
# model_gpt_4o_mini = "gpt-4o-mini-2024-07-18-call-dev"
# model_gpt_4o = "gpt-4o-2024-08-06-call-dev"
# model_api_version = "2024-10-21"
# model_host = 'https://oai-pn-its-aoai-eus2-455.openai.azure.com'
# bearer_token_provider_url = "https://cognitiveservices.azure.com/.default"

# os.environ['model_gpt_4o_mini'] = model_gpt_4o_mini
# os.environ['model_gpt_4o'] = model_gpt_4o
# os.environ['model_api_version'] = model_api_version
# os.environ['model_host'] = model_host
# os.environ['bearer_token_provider_url'] = bearer_token_provider_url

# COMMAND ----------

# import sys
# sys.path.append("/Workspace/Users/ds01@blueshieldca.com/BSC_CallIntent_Provider_4Feb/CII Pipeline")

# COMMAND ----------

# # # Default model and tokenizer values 
# # # DO NOT CHANGE BELOW CODE
# import os
# model_gpt_4o_mini = "gpt-4o-mini-2024-07-18-call-dev"
# model_gpt_4o = "gpt-4o-2024-08-06-call-dev"
# model_api_version = "2024-10-21"
# model_host = 'https://oai-pn-its-aoai-eus2-455.openai.azure.com'
# bearer_token_provider_url = "https://cognitiveservices.azure.com/.default"

# os.environ['model_gpt_4o_mini'] = model_gpt_4o_mini
# os.environ['model_gpt_4o'] = model_gpt_4o
# os.environ['model_api_version'] = model_api_version
# os.environ['model_host'] = model_host
# os.environ['bearer_token_provider_url'] = bearer_token_provider_url

# COMMAND ----------

import os
import json
import time
import pandas as pd
import re

from generic_pipeline.actionable_insights import reason_standardization ,error_check,save_log_json

# COMMAND ----------

def get_standardized_string(input_string):
    try:
        lines = input_string.split("\n")
        result = []
        updated_string = ""
        for line in lines:
            if (len(updated_string) + len(line)) < 252:
                updated_string = updated_string + f"- {line}\n"
        return updated_string.strip()
    except Exception as e:
        return ""
    
def remove_unwanted_str(input):
    lines=input.split("\n")
    new_str=""
    for line in lines:
        if "Miscellaneous" in line or "failed 0.0%" in line or "- failed" in line:
            print("----")
        else:
            new_str+=line+"\n"
    new_str=new_str.strip().strip("\n").strip()
    return new_str

def get_standardized_columns(df):
    df["insights_1"] = [""]*len(df)
    df["actionables_1"] = [""]*len(df)
    df["insights_2"] = [""]*len(df)
    df["actionables_2"] = [""]*len(df)
    df["insights_3"] = [""]*len(df)
    df["actionables_3"] = [""]*len(df)
    df["insights_4"] = [""]*len(df)
    df["actionables_4"] = [""]*len(df)
    df["insights_5"] = [""]*len(df)
    df["actionables_5"] = [""]*len(df)
    for i in range(len(df["name_of_top_driver"])):
        df["insights"][i] = remove_unwanted_str(df["insights"][i])
        df["insights_1"][i]  = get_standardized_string(df["insights"][i])
        df["insights_1"][i] = remove_unwanted_str(df["insights_1"][i])

        df["actionables_1"][i] = get_standardized_string(df["actionables"][i])
        if isinstance(df["insights_1"][i], float) or df["insights_1"][i].strip() == "":
            df["insights_1"][i] = "- No Insights"
        if isinstance(df["tier2"][i], float) or df["tier2"][i].strip()== "" :
            df["tier2"][i] = "Not Applicable"
        if isinstance(df["tier3"][i], float) or df["tier3"][i].strip()== "":
            df["tier3"][i] = "Not Applicable"
        if isinstance(df["tier4"][i], float) or df["tier4"][i].strip()== "":
            df["tier4"][i] = "Not Applicable"
        if isinstance(df["tier5"][i], float) or df["tier5"][i].strip()== "":
            df["tier5"][i] = "Not Applicable"
        if isinstance(df["descriptive_tag1"][i], float) or df["descriptive_tag1"][i].strip()== "":
            df["descriptive_tag1"][i] = "Not Applicable"
        if isinstance(df["descriptive_tag2"][i], float) or df["descriptive_tag2"][i].strip()== "":
            df["descriptive_tag2"][i] = "Not Applicable"
    df["Sno"] = range(1, len(df)+1)
    return df 

def process_actionable_insights(input_folder_path):
    global model_gpt_4o_mini, model_gpt_4o, base_url, openai_databricks_token
    os.environ['model_gpt_4o_mini'] = model_gpt_4o_mini
    os.environ['model_gpt_4o'] = model_gpt_4o
    os.environ['base_url'] = base_url
    os.environ['openai_databricks_token'] = openai_databricks_token
    
    st=time.time()
    workspace_path = os.path.dirname(os.path.normpath(input_folder_path))
    insights_and_actionable_path = os.path.join(workspace_path ,"insights_and_actionable_data")
    if os.path.exists(insights_and_actionable_path) == False:
        os.makedirs(insights_and_actionable_path)
    log_file_path = insights_and_actionable_path
    op_file_path = insights_and_actionable_path
    try:
        filename='actionable_insights'
        op_log_file_name = os.path.join(log_file_path, filename+"_logs.json")
        op_log_file_name_2 = os.path.join(log_file_path, filename+"_logs_2.json")
        output_dataframe=reason_standardization(input_folder_path,op_log_file_name_2,max_workers=8)
        
        output = output_dataframe.to_dict(orient='records')
        print("Inside the method")
        error_status,error=error_check(output_dataframe)
        output_dataframe.head(10)
        
        end_time = time.time()
        time_taken = end_time - st
        print("Error status is "+str(error_status))
        if error_status == False:
            final_status = {"processed": "success","error_message" :"","op_file_path" :  op_log_file_name_2,'data': output,"processed_date":"","time_taken":time_taken}
            save_log_json(final_status,op_log_file_name)
        else:
            final_status = {"processed":"partial_error", "error_message" : error,"op_file_path" :  op_log_file_name_2,"processed_date" : "","data":output,"time_taken":time_taken}
            save_log_json(final_status,op_log_file_name)
        # output_dataframe.reset_index(drop=True,inplace=True)
        output_dataframe = get_standardized_columns(output_dataframe)
        # df_non_others = output_dataframe[output_dataframe['category_with_descriptive_tag'] != 'Others'].reset_index(drop=True)
        # df_others = output_dataframe[output_dataframe['category_with_descriptive_tag'] == 'Others'].reset_index(drop=True)
        # output_dataframe = pd.concat([df_non_others,df_others],ignore_index=True)
        output_dataframe.reset_index(drop=True,inplace=True)
        output_dataframe["Sno"] = range(1, len(output_dataframe)+1)
        output_dataframe["error_list"]=[""]*len(output_dataframe)
        output_dataframe['error_list']=[""]*len(output_dataframe)
        return output_dataframe, final_status
    except Exception as e:
        final_status = {"processed":"failed", "error_message" : str(e),"op_file_path" : "","processed_date" : "","data":{},"time_taken":0}
        save_log_json(final_status,op_log_file_name)
    return None, final_status

# COMMAND ----------

# output_dataframe, final_status = process_actionable_insights("/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_intent_testing/provider/v0provider/output/")

# COMMAND ----------

# output_dataframe["insights_1"][0]

# COMMAND ----------



# COMMAND ----------


# updated_spark_df = spark.createDataFrame(output_dataframe)

# ### Name of the delta table which we want to create
# new_delta_table_path = "provider_work_call_insights"

# CATALOG_NAME = "dbc_adv_anlaytics_dev"
# SCHEMA_NAME = "surveyspeechextraction"
# full_name = f"{CATALOG_NAME}.{SCHEMA_NAME}.{new_delta_table_path}"
# # Write the updated Spark DataFrame to the new Delta table

# spark.sql(f"USE CATALOG {CATALOG_NAME}")
# spark.sql(f"USE SCHEMA {SCHEMA_NAME}")
# updated_spark_df.write.format("delta").mode("overwrite").option("overwriteSchema", "True").saveAsTable(full_name)



# COMMAND ----------

