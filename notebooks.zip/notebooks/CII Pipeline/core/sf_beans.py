import json

from core.common_utils import get_num_tokens

class AnalyticsManager:
    def __init__(self, db_client, llm_analytics_table_name):
        self.db_client = db_client
        self.llm_analytics_table_name = llm_analytics_table_name

        #llm analytics"
        self.name = None
        self.llm_input_tokens = None
        self.llm_output_tokens = None
        self.llm_duration = None
        self.llm_input = None
        self.llm_output = None

    def save_llm_request(self):
        insert_query = f"""INSERT INTO {self.llm_analytics_table_name} (`name`, `request`, `response`, `duration`, `input_tokens`, `output_tokens`) VALUES (%s, %s, %s, %s, %s, %s)"""
        values = (self.name, self.llm_input, self.llm_output, self.llm_duration, self.llm_input_tokens, self.llm_output_tokens)
        self.db_client.insert(query=insert_query, values=values)

    def add_name(self, name):
        self.name = name

    def add_llm_input_tokens(self, llm_input):
        num_tokens = 0
        if isinstance(llm_input, list):
            self.llm_input = json.dumps(llm_input)
            for msg in llm_input:
                content = msg["content"]
                num_tokens += get_num_tokens(content)
        
        elif isinstance(llm_input, str):
            self.llm_input = llm_input
            num_tokens = get_num_tokens(llm_input)
        else:
            raise Exception("Unsupported llm input message format")
        
        self.llm_input_tokens = num_tokens


    def add_llm_output_tokens(self, llm_output):
        num_tokens = 0
        if isinstance(llm_output, str):
            self.llm_output = llm_output
            num_tokens = get_num_tokens(llm_output)
        else:
            raise Exception(f"Unsupported llm output message format: {type(llm_output)}")

        self.llm_output_tokens = num_tokens

    def add_llm_duration(self, duration):
        self.llm_duration = duration