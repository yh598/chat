# Databricks notebook source
# MAGIC %md
# MAGIC ##### Set Source and Target directories for Sagility, and BSC

# COMMAND ----------

#Update below if required
source_directory =  "/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_intent_workspace/common_filter/IFP/"
target_directory = "/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_intent_workspace/common_filter/IFP/"

import os
if not os.path.exists(target_directory):
    os.makedirs(target_directory)


# COMMAND ----------

# MAGIC %md
# MAGIC Set Parameters for Delta Table

# COMMAND ----------

#parameters for delta table (DO NOT CHANGE)
CATALOG_NAME = "dbc_adv_anlaytics_dev"
SCHEMA_NAME = "surveyspeechextraction"

TABLE_NAME = "ifp_work_call_intent"
ETL_LOG_TABLE_NAME = "Daily_Transcript_Logs"

# COMMAND ----------

# MAGIC %md
# MAGIC Initialize Model Details

# COMMAND ----------

# Default model and tokenizer values 
# DO NOT CHANGE BELOW CODE
import os
import os
model_gpt_4o_mini = "azure-gpt-4o-mini-2024-07-18-call-mccp"
model_gpt_4o = "azure-gpt-4o-2024-08-06-call-mccp"
base_url = "https://adb-640321604414221.1.azuredatabricks.net/serving-endpoints"
openai_databricks_token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()


# COMMAND ----------

# MAGIC %md
# MAGIC Path to Ontology Sheet
# MAGIC
# MAGIC ### Mandantory columns names should be in ["Tier1","Tier2",Tier3"].
# MAGIC ### 
# MAGIC ### Optional columns names should be in ["Tier4",	"Tier5","DescriptiveTag1","DescriptiveTag2"]

# COMMAND ----------


ontology_sheet_path="./CII Pipeline/generic_pipeline/category_data/Member Ontology.xlsx"
ontology_sheet_name = "Sheet1"

simple_intent_list_path= "./CII Pipeline/generic_pipeline/category_data/Member Ontology Simple Intents.xlsx"
# Required Cloumns

"""
mandantory columns names should be ["Tier1","Tier2",Tier3"]	
optional columns names["Tier4",	"Tier5","DescriptiveTag1","DescriptiveTag2"]
"""


# COMMAND ----------

# MAGIC %md
# MAGIC Get Current Date and Time

# COMMAND ----------

from datetime import datetime, timedelta
import os
def get_current_date_and_time():
        current_date = datetime.now()-timedelta(days=4)
        formatted_date = current_date.strftime("%Y-%m-%d")
        formatted_time = current_date.time().strftime("%H:%M:%S")
        return formatted_date, formatted_time

# COMMAND ----------

# MAGIC %md
# MAGIC  Set Up Workspace Folders

# COMMAND ----------

# Setting up workspace folders
folder_to_execute = get_current_date_and_time()[0]
workspace_path = os.path.join(target_directory, folder_to_execute)
to_process_path =  workspace_path + "/to_process"
op_file_path =  workspace_path + "/output"
archive_path =  workspace_path + "/archive"
log_file_path = workspace_path + "/logs"


# COMMAND ----------

# MAGIC %md
# MAGIC Create Workspace path if doesnt exists

# COMMAND ----------

if not os.path.exists(workspace_path):
    os.makedirs(workspace_path)
if not os.path.exists(to_process_path):
    os.makedirs(to_process_path)
if not os.path.exists(op_file_path):
    os.makedirs(op_file_path)
if not os.path.exists(archive_path):
    os.makedirs(archive_path)
if not os.path.exists(log_file_path):
    os.makedirs(log_file_path)

# COMMAND ----------

print(f'Input Source Path:\n {source_directory} \n')
print(f'Workspace Path:\n {workspace_path} \n')
print(f'Output Json Path:\n {op_file_path} \n')
print(f'Log path:\n {log_file_path} \n')
print(f'Archive path :\n {archive_path}\n')
print(f'Delta table to update:\n {CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}')

# COMMAND ----------

# MAGIC %md
# MAGIC Set up Databases Flag

# COMMAND ----------

SNOWFLAKE_CONNECTION = "ON"
NETEZZA_CONNECTION = "ON"
VERINT_CONNECTION = "OFF"

print(f"SNOWFLAKE_CONNECTION set to: {SNOWFLAKE_CONNECTION}")
print(f"NETEZZA_CONNECTION set to: {NETEZZA_CONNECTION}")
print(f"VERINT_CONNECTION set to: {VERINT_CONNECTION}")