# Databricks notebook source
# MAGIC %md
# MAGIC Set Up Parameters for Delta Table

# COMMAND ----------

#parameters for delta table (DO NOT CHANGE)
# CATALOG_NAME = "dbc_adv_anlaytics_dev"
# SCHEMA_NAME = "surveyspeechextraction"
# TABLE_NAME =  "core_premier_work_call_insights"
CATALOG_NAME = config['catalog_name']
SCHEMA_NAME = config['schema_name']
TABLE_NAME = config['REASONS_TABLE_NAME']

# COMMAND ----------

# Default model and tokenizer values 
# DO NOT CHANGE BELOW CODE
import os
# model_gpt_4o_mini = "gpt-4o-mini-2024-07-18-call-ifp"
# model_gpt_4o = "gpt-4o-2024-08-06-call-ifp"
model_gpt_4o_mini = config['model_gpt_4o_mini']
model_gpt_4o = config['model_gpt_4o']
base_url = config['base_url']
model_api_version = "2024-10-21"
model_host = 'https://oai-pn-its-aoai-eus2-455.openai.azure.com'
bearer_token_provider_url = "https://cognitiveservices.azure.com/.default"
