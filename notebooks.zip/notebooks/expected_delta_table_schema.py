# Databricks notebook source
# MAGIC %md
# MAGIC Import Required Libraries

# COMMAND ----------

from pyspark.sql.functions import explode, col
from pyspark.sql.types import StructType, StructField, StringType, FloatType, LongType, DoubleType, IntegerType


# COMMAND ----------

# MAGIC %md
# MAGIC Define Schema for Expected Delta Table

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, DoubleType, LongType, IntegerType, ArrayType

def get_expected_table_schema() -> StructType:
    """
    Returns the expected schema for the table.
    """
    schema = StructType([
        StructField("id", StringType(), True),
        StructField("conversation_filename", StringType(), True),
        StructField("conversation_length_sec", DoubleType(), True),
        StructField("conversation_language", StringType(), True),
        StructField("conversation_start_date", StringType(), True),
        StructField("conversation_end_date", StringType(), True),
        StructField("conversation_start_time", StringType(), True),
        StructField("conversation_end_time", StringType(), True),
        StructField("conversation_processed_date", StringType(), True),
        StructField("conversation_process_time", StringType(), True),
        StructField("agent_talk_time_in_sec", DoubleType(), True),
        StructField("customer_talk_time_in_sec", DoubleType(), True),
        StructField("LOB", StringType(), True),
        
        # Flatten source_metadata
        StructField("AUDIO_START_TIME", StringType(), True),
        StructField("Source_db", StringType(), True),
        StructField("Sid", LongType(), True),
        StructField("Site_id", LongType(), True),
        StructField("Audio_ch_num", LongType(), True),
        StructField("Audio_module_num", LongType(), True),
        StructField("Audio_start_time_gmt", StringType(), True),
        StructField("Transaction_id", StringType(), True),
        StructField("ContactID", StringType(), True),
        StructField("Personal_id", StringType(), True),
        StructField("org_id", StringType(), True),
        StructField("Direction", LongType(), True),
        StructField("Local_audio_start_time", StringType(), True),
        StructField("Local_audio_end_time", StringType(), True),
        StructField("Wrapup_time", StringType(), True),
        StructField("Agent_name", StringType(), True),
        StructField("Total_hold_time", StringType(), True),
        StructField("Pbx_login_id", StringType(), True),
        StructField("Ani", StringType(), True),
        StructField("Extension", StringType(), True),
        StructField("String_extension", StringType(), True),
        StructField("Switch_call_id", StringType(), True),
        StructField("Switch_id", StringType(), True),
        StructField("Duration_seconds", LongType(), True),
        StructField("Wrapup_time_in_seconds", StringType(), True),
        StructField("Dnis", StringType(), True),
        StructField("Number_of_conferences", StringType(), True),
        StructField("Number_of_holds", StringType(), True),
        StructField("Number_of_transfers", StringType(), True),
        StructField("Percent_of_agent_call", StringType(), True),
        StructField("Percent_of_other_call", StringType(), True),
        StructField("Percent_of_mutual_silence", StringType(), True),
        StructField("Num_of_agent_cross", StringType(), True),
        StructField("Num_of_other_cross", StringType(), True),
        StructField("Language_code", StringType(), True),
        StructField("IsException", LongType(), True),
        StructField("CD1", StringType(), True),
        StructField("CD8", StringType(), True),
        StructField("CD6", StringType(), True),
        StructField("CD10", StringType(), True),
        StructField("CD12", StringType(), True),
        StructField("CD14", StringType(), True),
        StructField("CD15", StringType(), True),
        StructField("CD17", StringType(), True),
        StructField("CD26", StringType(), True),
        StructField("CD27", StringType(), True),
        StructField("CD28", StringType(), True),
        StructField("CD40", StringType(), True),
        StructField("CD48", StringType(), True),
        StructField("CD69", StringType(), True),
        StructField("CD93", StringType(), True),

        # Flatten speech_module_output
        StructField("transcript", StringType(), True),

        # Flatten overall_level
        StructField("call_driver_summary", StringType(), True),
        StructField("call_driver_sentence", StringType(), True),
        StructField("classified_category", ArrayType(StringType()), True),
        StructField("tier1", StringType(), True),
        StructField("tier2", StringType(), True),
        StructField("tier3", StringType(), True),
        StructField("tier4", StringType(), True),
        StructField("tier5", StringType(), True),
        StructField("descriptive_tag1", StringType(), True),
        StructField("descriptive_tag2", StringType(), True),
        StructField("Number_of_intents_Call_level", StringType(), True),
        StructField("tier1_combo", StringType(), True),
        StructField("tier1_2_combo", StringType(), True),
        StructField("category_combo1", StringType(), True),
        StructField("category_combo2", StringType(), True),
        StructField("category_combo3", StringType(), True),
        StructField("category_combo4", StringType(), True),
        StructField("category_combo5", StringType(), True),

        # New additional fields
        StructField("callback_request", StringType(), True),
        StructField("callback_request_speaker", StringType(), True),
        StructField("callback_explanation", StringType(), True),
        StructField("call_complexity_engine_generated", StringType(), True),
        StructField("call_complexity_explanation_engine_generated", StringType(), True),
        StructField("call_complexity_explanation_engine_generated_decision_logic", StringType(), True),
        StructField("customer_attrition_indicator", StringType(), True),
        StructField("reason_for_customer_attrition_indicator", StringType(), True),
        StructField("customer_sentiment_at_end_of_call", StringType(), True),
        StructField("customer_sentiment_at_end_of_call_explanation", StringType(), True),
        StructField("customer_sentiment_towards_bsc", StringType(), True),
        StructField("customer_sentiment_towards_bsc_reason", StringType(), True),
        StructField("customer_sub_sentiment_towards_bsc", StringType(), True),
        StructField("customer_sub_sentiment_towards_bsc_reason", StringType(), True),
        StructField("summary", StringType(), True),
        StructField("marked_cases", StringType(), True),
        StructField("presence_of_customer_intent", StringType(), True),
        StructField("classified_category", StringType(), True),
        StructField("Number_of_intents_Call_level", IntegerType(), True),
        StructField("tier1_combo", StringType(), True),
        StructField("tier1_2_combo", StringType(), True),
        StructField("category_with_descriptive_tag_call_level", StringType(), True),
        StructField("category_combo1", StringType(), True),
        StructField("category_combo2", StringType(), True),
        StructField("category_combo3", StringType(), True),
        StructField("category_combo4", StringType(), True),
        StructField("category_combo5", StringType(), True),

        # New fields from cii_output["info"]
        StructField("total_time_taken", DoubleType(), True),
        StructField("total_number_of_llm_hit", DoubleType(), True),
        StructField("total_input_token", DoubleType(), True),
        StructField("total_output_token", DoubleType(), True),

        StructField("is_Active", DoubleType(), True),

        # Additional fields 
        StructField("Member_ID", StringType(), True),                       
        StructField("Member_Registered", StringType(), True),               
        StructField("Last_Online", StringType(), True),                     
        StructField("Call_Satisfaction_Score", IntegerType(), True),        
        StructField("Customer_Sentiment", StringType(), True),              
        StructField("NPS", IntegerType(), True),                           
        StructField("Tenure", IntegerType(), True),                        
        StructField("Plan", StringType(), True),                            
        StructField("Geo_County", StringType(), True),
        StructField("State", StringType(), True), 
        StructField("LOB2", StringType(), True), 
        StructField("Member_Age", StringType(), True),   
        StructField("marked_cases", DoubleType(), True),
        StructField("presence_of_customer_intent", StringType(), True),                      
        StructField("Simple_or_Complex_Call", StringType(), True),
        StructField("Skill_Names", StringType(), True)
    ])
    return schema