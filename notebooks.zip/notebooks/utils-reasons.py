# Databricks notebook source
# MAGIC %md
# MAGIC Update Delta table Method

# COMMAND ----------

def update_delta_table(df, CATALOG_NAME, SCHEMA_NAME, TABLE_NAME):
    '''
    Function to update delta table

    Args:
    df (DataFrame): dataframe to load into delta table
    CATALOG_NAME: catalog name accessed from config notebook
    SCHEMA_NAME: schema name accessed from config notebook
    TABLE_NAME: table name accessed from config notebook

    Returns:
    status of update operation
    '''
    spark.sql(f"USE CATALOG {CATALOG_NAME}")
    spark.sql(f"USE SCHEMA {SCHEMA_NAME}")
    try: 
        if spark.catalog.tableExists(f"{CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}"):
            df.write.format("delta")\
                .mode("append")\
                .option("overwriteSchema", "False")\
                .option("mergeSchema", "False")\
                .saveAsTable(f"{CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}")
            return f"successfully updated {CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}"
        else:
            print(f"Table doesn't exist. Creating {CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME} table")
            df.write.format("delta")\
                .saveAsTable(f"{CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}")
            return f"created new table {CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}"      
    except Exception as e:
        print(f"Error updating delta table: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC Logging for Stages

# COMMAND ----------

import time
import pandas as pd

# Initialize an empty list to store log entries
log_entries = []

def log_stage(stage, start_time, status, log_message):
    end_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    log_entries.append({
        "Stage": stage,
        "Start Time": start_time,
        "End Time": end_time,
        "Status": status,
        "Log": log_message
    })


# COMMAND ----------

import os
import pandas as pd

def write_log_to_file(file_path):
    if os.path.exists(file_path):
        # Read existing log entries
        existing_log = pd.read_csv(file_path)
        # Append new log entries
        updated_log = pd.concat([existing_log, pd.DataFrame(log_entries)], ignore_index=True)
    else:
        # Create new log entries
        updated_log = pd.DataFrame(log_entries)
    
    # Write the updated log to the file
    updated_log.to_csv(file_path, index=False)