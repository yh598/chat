# Databricks notebook source
# MAGIC %md
# MAGIC Config setup for Verint

# COMMAND ----------

!pip install openpyxl
!pip install aiofiles
dbutils.library.restartPython() 

# COMMAND ----------

source_directory_verint ="/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/2024_verint_transcripts/Daily Transcripts/"
start_date = "2025-03-22"
end_date = "2025-03-25"
target_directory_verint ="/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_driver_poc/common_filter_testing_adhoc/"

import os
if not os.path.exists(target_directory_verint):
    os.makedirs(target_directory_verint)

# COMMAND ----------

# MAGIC %md
# MAGIC Current Date and time

# COMMAND ----------

from datetime import datetime, timedelta
import os
def get_current_date_and_time():
        current_date = datetime.now()-timedelta(days=4)
        # current_date = datetime.now()-timedelta(days=12)
        # print("Current date and time: ", current_date)
        # Format the date in "dd/mm/yyyy" format
        formatted_date = current_date.strftime("%Y-%m-%d")
        formatted_time = current_date.time().strftime("%H:%M:%S")
        return formatted_date, formatted_time

# COMMAND ----------

# MAGIC %md
# MAGIC Setup Workspaces

# COMMAND ----------


# Setting up workspace folders
folder_to_execute = get_current_date_and_time()[0]
workspace_path = target_directory_verint

# Define the main folders
folders = ["MA", "IFP", "Broker","Small Group","MediCal","Core Premier"]

# Create paths for each main folder and their subfolders
paths = {}
for folder in folders:
    paths[folder] = {
        "to_process_path": os.path.join(workspace_path, folder, folder_to_execute, "to_process", "Verint"),
        "op_file_path": os.path.join(workspace_path, folder, folder_to_execute, "output", "Verint"),
        "archive_path": os.path.join(workspace_path, folder, folder_to_execute, "archive", "Verint"),
        "log_file_path": os.path.join(workspace_path, folder, folder_to_execute, "logs", "Verint")
    }

# Add paths for raw_unzip_files and Original_zip_files inside other_lobs
raw_unzip_path = os.path.join(workspace_path,  "raw_unzip_files",folder_to_execute)
original_zip_files = os.path.join(workspace_path,"original_zip_files" ,folder_to_execute)

# Print paths for each main folder and their subfolders
for folder, subfolders in paths.items():
    print(f'Paths for {folder}:')
    for subfolder_name, subfolder_path in subfolders.items():
        print(f'{subfolder_name}: {subfolder_path}')
    print()

# Print paths for raw_unzip_files and original_zip_files
print(f'raw_unzip_path: {raw_unzip_path}')
print(f'original_zip_files: {original_zip_files}')

# COMMAND ----------


# Create the workspace directory if it doesn't exist
if not os.path.exists(workspace_path):
    os.makedirs(workspace_path)

# Create the subdirectories for each main folder
for folder, subfolders in paths.items():
    for subfolder_name, subfolder_path in subfolders.items():
        if not os.path.exists(subfolder_path):
            os.makedirs(subfolder_path)

# COMMAND ----------

# Print paths for each main folder and their subfolders
for folder, subfolders in paths.items():
    print(f'Paths for {folder}:')
    for subfolder_name, subfolder_path in subfolders.items():
        print(f'{subfolder_name}: {subfolder_path}')
    print()


# COMMAND ----------

# MAGIC %md
# MAGIC Setup configurations

# COMMAND ----------

# MAGIC %run "./Unzip_Filter"

# COMMAND ----------

# MAGIC %md
# MAGIC Step1: Unzip All files to target directory

# COMMAND ----------

try:
    # verint_unzip=unzip_verint_files(source_directory_verint, folder_to_execute, raw_unzip_path, original_zip_files)
    # for unzip all files
    verint_unzip=asyncio.run(unzip_verint_files(source_directory_verint, start_date,end_date,raw_unzip_path, original_zip_files))
except Exception as e:
    print(f'Error in Unzipping files: {e}')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Global Common Filter

# COMMAND ----------

# # Load the Excel files into DataFrames
all_lob_excel_path = "./ALL_LOB_Skill_IDS.xlsx"

# COMMAND ----------

try:
    global_filter(verint_unzip, folder_to_execute, all_lob_excel_path, paths)
except Exception as e:
    print(f'Error in global_filter: {e}')