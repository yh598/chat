# Databricks notebook source
# MAGIC %md
# MAGIC Txt File Creation

# COMMAND ----------

# %python
# import os
# from datetime import datetime

# # Define the source paths
# source_paths = [
#     "/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_driver_poc/common_filter_testing/Text_File_Insertion/IFP/",
#     "/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_driver_poc/common_filter_testing/Text_File_Insertion/Broker/",
#     "/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_driver_poc/common_filter_testing/Text_File_Insertion/Provider/",
#     "/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_driver_poc/common_filter_testing/Text_File_Insertion/Core_Premier/",
#     "/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_driver_poc/common_filter_testing/Text_File_Insertion/MediCal/",
#     "/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_driver_poc/common_filter_testing/Text_File_Insertion/Small Group/"
# ]

# #create paths if not exists
# for source_path in source_paths:
#     if not os.path.exists(source_path):
#         os.makedirs(source_path)

# # Get the current date and time
# current_datetime = datetime.now().strftime("%Y%m%d_%H%M%S")

# # Define the file name with the current date and time stamp
# file_name = f"Filter_{current_datetime}.txt"
# file_content = f"Date: {datetime.now().strftime('%Y-%m-%d')}, Time: {datetime.now().strftime('%H:%M:%S')}"

# # Iterate over each source path and create the file
# for source_path in source_paths:

#     # Create the full file path
#     file_path = os.path.join(source_path, file_name)
    
#     # Write the content to the file
#     with open(file_path, "w") as file:
#         file.write(file_content)
    
#     print(f"File {file_name} created at {source_path}")