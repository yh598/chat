# Databricks notebook source
# MAGIC %md
# MAGIC ##### Config-Setup for Ttec

# COMMAND ----------

!pip install openpyxl
!pip install aiofiles
dbutils.library.restartPython() 

# COMMAND ----------

source_directory_ttec = "/Volumes/prod_adb/default/synapse_volume/raw/surveyspeechextraction/TTEC/"
start_date="2025-03-01"
end_date='2025-03-03'
target_directory_ttec = "/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_driver_poc/common_filter_testing_adhoc/"

import os
if not os.path.exists(target_directory_ttec):
    os.makedirs(target_directory_ttec)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Current Date and time

# COMMAND ----------

from datetime import datetime, timedelta
import os
def get_current_date_and_time():
        current_date = datetime.now()-timedelta(days=3)
        # current_date = datetime.now()-timedelta(days=12)
        # print("Current date and time: ", current_date)
        # Format the date in "dd/mm/yyyy" format
        formatted_date = current_date.strftime("%Y-%m-%d")
        formatted_time = current_date.time().strftime("%H:%M:%S")
        return formatted_date, formatted_time

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Setup Workspaces

# COMMAND ----------


# Setting up workspace folders
folder_to_execute = get_current_date_and_time()[0]
workspace_path = target_directory_ttec

# Define the main folders
folders = ["Small Group", "IFP", "Broker"]

# Create paths for each main folder and their subfolders
paths = {}
for folder in folders:
    paths[folder] = {
        "to_process_path": os.path.join(workspace_path, folder, folder_to_execute, "to_process", "TTec"),
        "op_file_path": os.path.join(workspace_path, folder, folder_to_execute, "output", "TTec"),
        "archive_path": os.path.join(workspace_path, folder, folder_to_execute, "archive", "TTec"),
        "log_file_path": os.path.join(workspace_path, folder, folder_to_execute, "logs", "TTec")
    }

# Add paths for raw_unzip_files and Original_zip_files inside other_lobs
raw_unzip_path = os.path.join(workspace_path,  "raw_unzip_files",folder_to_execute)
original_zip_files = os.path.join(workspace_path,"original_zip_files" ,folder_to_execute)

# Print paths for each main folder and their subfolders
for folder, subfolders in paths.items():
    print(f'Paths for {folder}:')
    for subfolder_name, subfolder_path in subfolders.items():
        print(f'{subfolder_name}: {subfolder_path}')
    print()

# Print paths for raw_unzip_files and original_zip_files
print(f'raw_unzip_path: {raw_unzip_path}')
print(f'original_zip_files: {original_zip_files}')

# COMMAND ----------


# Create the workspace directory if it doesn't exist
if not os.path.exists(workspace_path):
    os.makedirs(workspace_path)

# Create the subdirectories for each main folder
for folder, subfolders in paths.items():
    for subfolder_name, subfolder_path in subfolders.items():
        if not os.path.exists(subfolder_path):
            os.makedirs(subfolder_path)

# COMMAND ----------

# Print paths for each main folder and their subfolders
for folder, subfolders in paths.items():
    print(f'Paths for {folder}:')
    for subfolder_name, subfolder_path in subfolders.items():
        print(f'{subfolder_name}: {subfolder_path}')
    print()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Setup configurations for global filter

# COMMAND ----------

# MAGIC %run "./Unzip_Filter"

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Unzip all transcripts to target path

# COMMAND ----------

unzip_path_ttec=unzip_ttec_files(source_directory_ttec,start_date,end_date,original_zip_files, raw_unzip_path, folder_to_execute)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Global Common Filter

# COMMAND ----------

all_lob_excel_path="./ALL_LOB_Skill_IDS.xlsx"

# COMMAND ----------

try:
    filter_ttec_files(unzip_path_ttec,all_lob_excel_path, paths)
except Exception as e:
    print(f"Error occurred while filtering the files: {e}")